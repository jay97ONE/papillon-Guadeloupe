# 📥 TÉLÉCHARGEMENT GITHUB - GUIDE ULTRA-SIMPLE

## 🎯 CE QU'IL FAUT FAIRE

Créer un dossier propre pour GitHub avec seulement les fichiers nécessaires.

---

## 🚀 MÉTHODE RAPIDE EN 3 ÉTAPES

### ✅ ÉTAPE 1 : CRÉER UN NOUVEAU DOSSIER

Sur votre ordinateur, créez un dossier :

```
📁 papillon-guadeloupe
```

---

### ✅ ÉTAPE 2 : COPIER CES FICHIERS

Depuis votre projet actuel, **copiez** dans le nouveau dossier :

#### 📄 **10 Fichiers Racine**

```
1.  .gitignore
2.  App.tsx
3.  index.html
4.  LICENSE
5.  main.tsx
6.  package.json          ← TRÈS IMPORTANT
7.  README.md
8.  tsconfig.json
9.  vercel.json
10. vite.config.ts
```

#### 📁 **4 Dossiers Complets**

```
1. components/           ← Tout le contenu (~61 fichiers)
2. pages/               ← Tout le contenu (12 fichiers)
3. public/              ← Tout le contenu (4 fichiers)
4. styles/              ← Tout le contenu (1 fichier)
```

---

### ✅ ÉTAPE 3 : VÉRIFIER

Votre nouveau dossier doit contenir :

```
papillon-guadeloupe/
├── components/          ✅
├── pages/              ✅
├── public/             ✅
├── styles/             ✅
├── .gitignore          ✅
├── App.tsx             ✅
├── index.html          ✅
├── LICENSE             ✅
├── main.tsx            ✅
├── package.json        ✅ ← CRITIQUE
├── README.md           ✅
├── tsconfig.json       ✅
├── vercel.json         ✅
└── vite.config.ts      ✅

TOTAL : ~88 fichiers
Taille : < 5 MB
```

---

## ⚠️ NE PAS COPIER

```
❌ node_modules/        ← Trop gros, sera auto-installé
❌ dist/                ← Sera auto-généré
❌ guidelines/          ← Documentation interne
❌ Tous les .md sauf README.md
❌ Fichiers .ps1 et .sh
```

---

## 🧪 TESTER LE DOSSIER

Dans le nouveau dossier, ouvrez un terminal :

```bash
# 1. Installer
npm install

# 2. Lancer
npm run dev
```

Si le site s'ouvre sur http://localhost:5173 → **C'EST BON !** ✅

---

## 📤 UPLOADER SUR GITHUB

### 1. Créer le Repository

- Allez sur **https://github.com**
- **New repository** → Nom : `papillon-guadeloupe`
- **Public** ✅ → **Create**

### 2. Uploader

- Cliquez **"uploading an existing file"**
- Glissez **TOUS les fichiers** de votre nouveau dossier
- **SAUF** `node_modules/` si vous l'avez créé
- **Commit changes**

### 3. Déployer

- Allez sur **https://vercel.com**
- **Sign up with GitHub**
- **Import project** : `papillon-guadeloupe`
- **Deploy**
- ⏱️ 2-3 minutes
- **🎉 SITE EN LIGNE !**

---

## 📋 CHECKLIST RAPIDE

- [ ] Nouveau dossier créé
- [ ] 10 fichiers racine copiés
- [ ] 4 dossiers complets copiés
- [ ] Total ~88 fichiers
- [ ] PAS de node_modules/
- [ ] PAS de dist/
- [ ] Testé avec npm install + npm run dev
- [ ] Uploadé sur GitHub
- [ ] Déployé sur Vercel
- [ ] Site accessible en ligne

---

## 💰 COÛT

**0€** - Tout est gratuit !

- ✅ GitHub : Gratuit
- ✅ Vercel : Gratuit
- ✅ HTTPS : Gratuit

**Optionnel** : Nom de domaine personnalisé = 6-8€/an

---

## 🎯 RÉSULTAT

Votre site sera en ligne sur :

```
https://papillon-guadeloupe.vercel.app
```

Accessible 24/7 partout dans le monde ! 🌍

---

## 📞 BESOIN D'AIDE ?

Consultez les guides détaillés :

- **PREPARATION_GITHUB.md** - Guide complet
- **FICHIERS_POUR_GITHUB.md** - Liste détaillée
- **DEPLOIEMENT_GITHUB.md** - Déploiement pas à pas

---

**🌴 PAPILLON GUADELOUPE SASU**  
SIRET : 830 230 603 00011  
Prêt pour le déploiement ! 🚀
