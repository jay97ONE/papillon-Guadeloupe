# 📤 INSTRUCTIONS RAPIDES - Upload sur GitHub

## 🎯 Ce Qu'il Faut Faire

### 1️⃣ PRÉPARER LES FICHIERS À UPLOADER

**Fichiers et Dossiers à INCLURE** ✅

```
✅ components/          (tout le dossier)
✅ pages/               (tout le dossier)
✅ public/              (tout le dossier)
✅ styles/              (tout le dossier)
✅ App.tsx
✅ main.tsx
✅ index.html
✅ package.json
✅ vite.config.ts
✅ tsconfig.json
✅ .gitignore
✅ vercel.json
✅ README.md
✅ DEPLOIEMENT_GITHUB.md
✅ GUIDE_DEPLOIEMENT_NOM_DE_DOMAINE.md
```

**Fichiers à NE PAS UPLOADER** ❌

```
❌ node_modules/       (trop gros, sera auto-installé)
❌ dist/               (sera auto-généré par Vercel)
❌ .DS_Store           (fichiers système Mac)
❌ Thumbs.db           (fichiers système Windows)
❌ *.log               (logs)

⚠️ Tous les fichiers .md de documentation peuvent être supprimés SAUF :
   ✅ README.md
   ✅ DEPLOIEMENT_GITHUB.md
   ✅ GUIDE_DEPLOIEMENT_NOM_DE_DOMAINE.md
```

---

## 2️⃣ CRÉER LE REPOSITORY GITHUB

### Via l'Interface Web (Plus Simple)

1. **Allez sur** : https://github.com
2. **Connectez-vous** ou **créez un compte**
3. **Cliquez** sur le bouton **"+"** en haut à droite
4. **Sélectionnez** : **"New repository"**

**Remplissez les informations** :
- **Repository name** : `papillon-guadeloupe`
- **Description** : `Site web officiel de Papillon Guadeloupe SASU - Architecte paysagiste de jardins d'exception en Guadeloupe`
- **Visibilité** : ☑️ **Public** (important pour déployer gratuitement)
- **Initialize** :
  - ❌ NE PAS cocher "Add a README file"
  - ❌ NE PAS ajouter .gitignore
  - ❌ NE PAS choisir de licence

5. **Cliquez** sur : **"Create repository"**

---

## 3️⃣ UPLOADER LES FICHIERS

### Méthode Drag & Drop (Glisser-Déposer)

1. **Sur la page du nouveau repository**, vous verrez :
   ```
   Quick setup — if you've done this kind of thing before
   ```

2. **Cliquez** sur le lien : **"uploading an existing file"**

3. **Ouvrez l'explorateur de fichiers** de votre ordinateur

4. **Sélectionnez TOUS les fichiers et dossiers** à uploader :
   - Maintenez `Ctrl` (Windows) ou `Cmd` (Mac) enfoncé
   - Cliquez sur chaque fichier/dossier à inclure
   - **OU** : Sélectionnez tout avec `Ctrl+A` / `Cmd+A`

5. **Glissez-déposez** tout dans la zone GitHub

6. **Attendez** que tous les fichiers apparaissent dans la liste

7. **En bas de la page** :
   - Message de commit : `Initial commit - Site Papillon Guadeloupe`
   - Description : `Site web complet avec React, TypeScript, Tailwind CSS`

8. **Cliquez** sur : **"Commit changes"**

9. ⏱️ **Attendez 1-3 minutes** que GitHub traite tous les fichiers

✅ **TERMINÉ !** Votre code est sur GitHub

---

## 4️⃣ VÉRIFIER L'UPLOAD

### Checklist de Vérification

Sur la page de votre repository GitHub, vérifiez que vous voyez :

```
✅ Dossier components/
✅ Dossier pages/
✅ Dossier public/
✅ Dossier styles/
✅ Fichier package.json
✅ Fichier README.md
✅ Fichier vite.config.ts
✅ Fichier tsconfig.json
✅ Fichier .gitignore
✅ Fichier App.tsx
✅ Fichier main.tsx
✅ Fichier index.html
```

**Le README.md devrait s'afficher** automatiquement en bas de la page.

---

## 5️⃣ DÉPLOYER SUR VERCEL

### Étapes Rapides

1. **Allez sur** : https://vercel.com

2. **Cliquez** sur : **"Sign Up"**

3. **Choisissez** : **"Continue with GitHub"**

4. **Autorisez** Vercel à accéder à GitHub

5. **Sur le Dashboard Vercel** :
   - Cliquez sur **"Add New..."**
   - Sélectionnez **"Project"**

6. **Vous verrez votre repository** : `papillon-guadeloupe`
   - Cliquez sur **"Import"**

7. **Configuration** (normalement auto-détectée) :
   - Framework Preset : **Vite** ✅
   - Build Command : `npm run build` ✅
   - Output Directory : `dist` ✅
   - Install Command : `npm install` ✅

8. **Cliquez** sur : **"Deploy"**

9. ⏱️ **Attendez 2-3 minutes**

10. 🎉 **SITE EN LIGNE !**

Vous obtiendrez une URL du type :
```
https://papillon-guadeloupe.vercel.app
```

---

## 6️⃣ TESTER LE SITE

### Pages à Vérifier

Testez toutes ces URLs :

```
✅ https://votre-site.vercel.app/
✅ https://votre-site.vercel.app/services
✅ https://votre-site.vercel.app/realisations
✅ https://votre-site.vercel.app/galerie
✅ https://votre-site.vercel.app/processus
✅ https://votre-site.vercel.app/contact
✅ https://votre-site.vercel.app/a-propos
✅ https://votre-site.vercel.app/faq
✅ https://votre-site.vercel.app/entretien-paysager
✅ https://votre-site.vercel.app/location-motoculteur
✅ https://votre-site.vercel.app/mentions-legales
```

### Vérifications

- ✅ Toutes les pages s'affichent correctement
- ✅ Les images sont visibles
- ✅ La navigation fonctionne
- ✅ Le site est responsive (mobile/tablette/desktop)
- ✅ Les animations fonctionnent
- ✅ Le formulaire de contact s'affiche

---

## ❓ PROBLÈMES COURANTS

### "Le site ne démarre pas sur Vercel"

**Solution** :
1. Vérifiez que `package.json` est bien uploadé
2. Allez dans **Vercel → Deployments**
3. Cliquez sur le dernier déploiement
4. Regardez les **logs** pour voir l'erreur
5. Si besoin, modifiez le fichier problématique sur GitHub
6. Vercel redéploiera automatiquement

### "Les images ne s'affichent pas"

**Vérifiez** :
1. Que le dossier `public/images/` est uploadé
2. Que `ImageConfig.tsx` est présent
3. Que les URLs dans `ImageConfig.tsx` sont valides

### "Page blanche / Erreur 404"

**Solution** :
1. Le fichier `vercel.json` devrait gérer ça automatiquement
2. Vérifiez qu'il est bien uploadé sur GitHub

---

## 📝 MODIFICATIONS FUTURES

### Pour mettre à jour le site après modifications :

**Méthode Simple** :

1. Allez sur votre repository GitHub
2. Naviguez jusqu'au fichier à modifier
3. Cliquez sur **"Edit"** (icône crayon ✏️)
4. Faites vos modifications
5. Cliquez sur **"Commit changes"**
6. ⏱️ Vercel redéploie automatiquement en 1-2 min !

**Méthode Upload** :

1. Modifiez les fichiers sur votre ordinateur
2. Sur GitHub, naviguez dans le dossier concerné
3. Cliquez sur **"Add file"** → **"Upload files"**
4. Glissez-déposez les fichiers modifiés
5. Commit → Vercel redéploie !

---

## 🎯 RÉSUMÉ DES ÉTAPES

```
1. ✅ Préparer les fichiers (exclure node_modules et dist)
2. ✅ Créer le repository sur GitHub
3. ✅ Uploader les fichiers (drag & drop)
4. ✅ Vérifier que tout est uploadé
5. ✅ Créer un compte Vercel avec GitHub
6. ✅ Importer le projet depuis GitHub
7. ✅ Déployer (2-3 minutes)
8. ✅ Tester le site en ligne
9. ✅ (Optionnel) Ajouter un nom de domaine
```

---

## 🚀 NEXT STEPS

Une fois le site en ligne sur Vercel :

1. **Testez tout** sur mobile, tablette, desktop
2. **Partagez l'URL** avec vos clients
3. **Ajoutez un domaine** personnalisé (voir `GUIDE_DEPLOIEMENT_NOM_DE_DOMAINE.md`)
4. **Configurez Google Analytics** (optionnel)
5. **Soumettez à Google Search Console** (SEO)

---

## 💡 CONSEILS

- **Sauvegardez** le lien de votre repository GitHub
- **Notez** l'URL Vercel de votre site
- **Gardez** vos identifiants GitHub et Vercel
- **Testez** régulièrement après modifications

---

**🎉 Vous êtes prêt à mettre votre site en ligne !**

**Temps total estimé** : 15-30 minutes (première fois)

---

**PAPILLON GUADELOUPE SASU**  
Architecte paysagiste de jardins d'exception  
SIRET : 830 230 603 00011
