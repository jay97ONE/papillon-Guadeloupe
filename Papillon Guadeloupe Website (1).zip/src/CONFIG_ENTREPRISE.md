# 📋 Configuration Entreprise - À Compléter

## ⚠️ IMPORTANT : Remplacer les valeurs ci-dessous

Ce fichier liste **TOUTES** les informations à remplacer avant la mise en production.

---

## 📞 COORDONNÉES À REMPLACER

### Email
**Actuel** : `contact@papillon-guadeloupe.com`  
**À remplacer par** : `_______________________________`

**Fichiers concernés** :
- [ ] `components/Layout.tsx` (ligne ~294)
- [ ] `pages/Contact.tsx` (ligne ~9)
- [ ] `pages/EntretienPaysager.tsx` (formulaire)
- [ ] `pages/LocationMotoculteur.tsx` (formulaire)
- [ ] `pages/MentionsLegales.tsx` (plusieurs endroits)
- [ ] `index.html` (meta tags)
- [ ] `README.md` (section Contact)

### Téléphone
**Actuel** : `+590 690 XX XX XX`  
**À remplacer par** : `_______________________________`

**Fichiers concernés** :
- [ ] `components/Layout.tsx` (ligne ~294)
- [ ] `pages/Contact.tsx` (ligne ~10)
- [ ] `pages/EntretienPaysager.tsx` (section CTA)
- [ ] `pages/LocationMotoculteur.tsx` (section CTA)
- [ ] `pages/MentionsLegales.tsx`
- [ ] `README.md`

### Adresse physique
**Actuel** : "Guadeloupe, Antilles françaises"  
**À remplacer par** : 
```
Rue/Avenue : _______________________________
Code postal : _______________________________
Ville : _______________________________
Complément : _______________________________
```

**Fichiers concernés** :
- [ ] `pages/MentionsLegales.tsx`
- [ ] `components/Layout.tsx` (footer si ajouté)

---

## 🏢 INFORMATIONS LÉGALES

### Entreprise
**Nom complet** : Papillon Guadeloupe Création  
**Forme juridique** : `_______________________________` (SARL, SAS, EI, Auto-entrepreneur, etc.)

### Identification
**SIRET** : `___ ___ ___ ___ ___`  
**SIREN** : `___ ___ ___`  
**RCS** : `_______________________________` (si applicable)  
**Code APE/NAF** : `_______________________________`

### TVA
**N° TVA intracommunautaire** : `_______________________________` (si applicable)  
**Assujetti à la TVA** : ☐ Oui ☐ Non

### Assurance
**Assurance professionnelle** : `_______________________________`  
**N° de contrat** : `_______________________________`  
**Organisme** : `_______________________________`

---

## 👤 DIRECTION

### Directeur de publication
**Nom complet** : `_______________________________`  
**Fonction** : `_______________________________` (Gérant, Président, etc.)

### Responsable éditorial (si différent)
**Nom** : `_______________________________`  
**Fonction** : `_______________________________`

---

## 🌐 HÉBERGEMENT WEB

### Hébergeur du site
**Nom** : `_______________________________` (ex: Netlify, OVH, O2Switch)  
**Adresse** : `_______________________________`  
**Code postal & Ville** : `_______________________________`  
**Téléphone** : `_______________________________`  
**Email** : `_______________________________`

---

## 🌍 DOMAINE & URLs

### Nom de domaine
**Actuel** : `papillon-guadeloupe.com`  
**Réel** : `_______________________________`

**À remplacer dans** :
- [ ] `index.html` (meta tags Open Graph)
- [ ] `public/robots.txt` (ligne Sitemap)
- [ ] `public/sitemap.xml` (toutes les URLs)
- [ ] `README.md`
- [ ] `pages/MentionsLegales.tsx`

### URLs réseaux sociaux (si disponibles)
**Facebook** : `_______________________________`  
**Instagram** : `_______________________________`  
**LinkedIn** : `_______________________________`  
**YouTube** : `_______________________________`

---

## 🎨 ASSETS GRAPHIQUES À CRÉER

### Favicons
Tous les fichiers à placer dans `/public/` :

- [ ] `favicon.svg` - Format vectoriel (recommandé)
- [ ] `favicon.ico` - Format legacy
- [ ] `favicon-16x16.png` - Petit favicon
- [ ] `favicon-32x32.png` - Favicon standard
- [ ] `favicon-192x192.png` - Android/Chrome
- [ ] `favicon-512x512.png` - Haute résolution
- [ ] `apple-touch-icon.png` - iOS (180x180px)

**Outil recommandé** : https://realfavicongenerator.net/

### Images Open Graph
À placer dans `/public/` :

- [ ] `og-image.jpg` - Facebook/LinkedIn (1200x630px)
- [ ] `twitter-image.jpg` - Twitter (1200x600px)

**Contenu suggéré** :
- Logo Papillon Guadeloupe
- Texte : "Architecte Paysagiste de Jardins d'Exception"
- Sous-texte : "Guadeloupe"
- Couleurs : Vert (#16a34a) et fond clair

**Outils** :
- Canva : https://www.canva.com/
- Figma : https://www.figma.com/
- Photopea (gratuit) : https://www.photopea.com/

---

## 📧 CONFIGURATION FORMULAIRES

### Service d'envoi d'emails
Choisir une option :

**Option A : Netlify Forms** (gratuit, 100 soumissions/mois)
- [ ] Activer dans Netlify Dashboard
- [ ] Modifier les formulaires (ajouter `data-netlify="true"`)

**Option B : Formspree** (gratuit, 50 soumissions/mois)
- [ ] Créer compte sur https://formspree.io/
- [ ] Obtenir l'endpoint
- [ ] Modifier les formulaires

**Option C : Backend personnalisé**
- [ ] Créer API d'envoi d'emails
- [ ] Configurer SMTP
- [ ] Modifier les formulaires

**Email de réception des formulaires** : `_______________________________`

---

## 📊 ANALYTICS (Optionnel)

### Google Analytics
**Compte créé** : ☐ Oui ☐ Non  
**ID de mesure (G-XXXXXXXXXX)** : `_______________________________`

**À ajouter dans `index.html`** entre `<head>` et `</head>` :
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

### Autres outils
**Google Search Console** : ☐ Configuré  
**Google My Business** : ☐ Créé  
**Plausible Analytics** : ☐ Configuré (alternative RGPD-friendly)

---

## 🔍 SEO

### Mots-clés principaux
Vérifier/compléter dans `index.html` :
```
paysagiste guadeloupe, architecte paysagiste, 
jardin tropical, conception 3D, aménagement extérieur,
entretien paysager, location motoculteur
```

**Mots-clés supplémentaires** : `_______________________________`

### Description
**Actuelle** : "Architecte paysagiste en Guadeloupe spécialisé dans la conception de jardins d'exception..."

**Personnalisée** (160 caractères max) :
```
_________________________________________________________
_________________________________________________________
```

---

## ✅ CHECKLIST DE REMPLACEMENT

### 1. Rechercher et remplacer globalement

Dans votre éditeur de code (VS Code, etc.) :

**Ctrl+Shift+H (ou Cmd+Shift+H sur Mac)** pour "Rechercher et remplacer dans tous les fichiers"

#### Remplacements à faire :

1️⃣ **Email**
```
Rechercher : contact@papillon-guadeloupe.com
Remplacer par : [VOTRE EMAIL RÉEL]
```

2️⃣ **Téléphone**
```
Rechercher : +590 690 XX XX XX
Remplacer par : [VOTRE TÉLÉPHONE RÉEL]
```

3️⃣ **Domaine**
```
Rechercher : papillon-guadeloupe.com
Remplacer par : [VOTRE DOMAINE RÉEL]
```

4️⃣ **Nom directeur** (dans MentionsLegales.tsx)
```
Rechercher : [Nom du directeur]
Remplacer par : [VOTRE NOM]
```

5️⃣ **Hébergeur** (dans MentionsLegales.tsx)
```
Rechercher : [Nom de l'hébergeur]
Remplacer par : [VOTRE HÉBERGEUR]
```

---

## 🚀 ORDRE DE FINALISATION RECOMMANDÉ

### Phase 1 : Informations essentielles (5 min)
1. [ ] Remplir email et téléphone réels
2. [ ] Faire les rechercher/remplacer globaux
3. [ ] Compléter MentionsLegales.tsx

### Phase 2 : Assets graphiques (10 min)
4. [ ] Générer les favicons
5. [ ] Créer images Open Graph
6. [ ] Les placer dans `/public/`

### Phase 3 : Domaine (2 min)
7. [ ] Remplacer le nom de domaine partout
8. [ ] Mettre à jour sitemap.xml

### Phase 4 : Build & Test (5 min)
9. [ ] `npm run build`
10. [ ] Vérifier qu'il n'y a pas d'erreurs
11. [ ] `npm run preview` et tester

### Phase 5 : Déploiement (10 min)
12. [ ] Déployer sur Netlify/Vercel
13. [ ] Configurer le domaine personnalisé
14. [ ] Activer HTTPS
15. [ ] Tester en production

---

## 📝 NOTES

### Conformité RGPD
- ✅ Pas de cookies de tracking sans consentement
- ✅ Formulaires avec information sur l'utilisation des données
- ✅ Page Mentions Légales créée
- ⚠️ À ajouter : Politique de confidentialité détaillée (optionnel)

### Accessibilité
- ✅ Contrastes de couleurs validés
- ✅ Navigation clavier fonctionnelle
- ✅ Textes alternatifs sur images importantes
- ⚠️ À tester : Lecteur d'écran

---

**Date de création** : 14 décembre 2024  
**À compléter avant** : Mise en production  
**Temps estimé** : 30 minutes

---

## 💾 SAUVEGARDER CE FICHIER

Une fois complété, ce fichier servira de référence pour :
- Maintenance future du site
- Mise à jour des informations
- Transmission à un développeur
- Documentation interne
