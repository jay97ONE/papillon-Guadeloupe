# Images - Papillon Guadeloupe

Ce dossier contient toutes les images du site web.

## Note Importante

Les images utilisées sur le site proviennent actuellement d'Unsplash via le composant `ImageConfig.tsx`.

Pour utiliser vos propres images :

1. Placez vos images dans ce dossier
2. Organisez-les par catégories (hero/, portfolio/, services/, etc.)
3. Mettez à jour le fichier `/components/ImageConfig.tsx` avec les chemins relatifs

## Structure Recommandée

```
images/
├── hero/           # Images pour la page d'accueil
├── portfolio/      # Photos de réalisations
├── services/       # Images pour les services
├── processus/      # Images pour le processus
└── logo/           # Logo et favicon
```

## Formats Recommandés

- **JPG** : Pour les photos
- **PNG** : Pour les logos avec transparence
- **WebP** : Pour une meilleure compression (optionnel)

## Optimisation

Optimisez vos images avant de les uploader pour améliorer les performances :
- **TinyPNG** : https://tinypng.com
- **Squoosh** : https://squoosh.app

## Taille Maximale

- Images : Max 2MB par fichier
- Dimensions : 1920x1080px maximum pour les grandes images
