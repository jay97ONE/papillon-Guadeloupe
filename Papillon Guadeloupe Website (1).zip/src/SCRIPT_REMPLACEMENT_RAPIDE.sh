#!/bin/bash

# 🔄 Script de remplacement rapide des coordonnées
# Pour Papillon Guadeloupe Création
# Usage : ./SCRIPT_REMPLACEMENT_RAPIDE.sh

echo "🦋 Script de finalisation Papillon Guadeloupe"
echo "=============================================="
echo ""

# Couleurs pour le terminal
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Demander les informations
echo -e "${YELLOW}📧 Entrez votre email réel :${NC}"
read -p "> " NEW_EMAIL

echo -e "${YELLOW}📱 Entrez votre téléphone réel (ex: +590 690 12 34 56) :${NC}"
read -p "> " NEW_PHONE

echo -e "${YELLOW}🌐 Entrez votre nom de domaine (ex: monsite.com) :${NC}"
read -p "> " NEW_DOMAIN

echo ""
echo "Vérification des informations :"
echo "------------------------------"
echo "Email    : $NEW_EMAIL"
echo "Téléphone: $NEW_PHONE"
echo "Domaine  : $NEW_DOMAIN"
echo ""
echo -e "${YELLOW}Ces informations sont-elles correctes ? (o/n)${NC}"
read -p "> " CONFIRM

if [ "$CONFIRM" != "o" ] && [ "$CONFIRM" != "O" ]; then
    echo "❌ Annulé. Relancez le script avec les bonnes informations."
    exit 1
fi

echo ""
echo "🔄 Remplacement en cours..."
echo ""

# Fonction pour remplacer dans tous les fichiers
replace_in_files() {
    local search="$1"
    local replace="$2"
    local description="$3"
    
    # Chercher et remplacer dans tous les fichiers .tsx, .ts, .html, .md
    find . -type f \( -name "*.tsx" -o -name "*.ts" -o -name "*.html" -o -name "*.md" -o -name "*.xml" -o -name "*.json" \) \
        ! -path "*/node_modules/*" \
        ! -path "*/.git/*" \
        ! -path "*/dist/*" \
        -exec sed -i.bak "s|$search|$replace|g" {} \;
    
    echo -e "${GREEN}✓${NC} $description"
}

# Effectuer les remplacements
replace_in_files "contact@papillon-guadeloupe.com" "$NEW_EMAIL" "Email mis à jour"
replace_in_files "+590 690 XX XX XX" "$NEW_PHONE" "Téléphone mis à jour"
replace_in_files "papillon-guadeloupe.com" "$NEW_DOMAIN" "Domaine mis à jour"

# Nettoyer les fichiers .bak créés par sed
find . -name "*.bak" -type f -delete

echo ""
echo -e "${GREEN}✅ Remplacement terminé !${NC}"
echo ""
echo "Prochaines étapes :"
echo "1. Vérifier les fichiers modifiés"
echo "2. Compléter pages/MentionsLegales.tsx"
echo "3. Générer les favicons (voir INSTRUCTIONS_FAVICONS.md)"
echo "4. Lancer npm run build"
echo ""
echo "🚀 Bonne finalisation !"
