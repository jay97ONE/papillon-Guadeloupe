# 🚀 Guide de Démarrage Rapide - Papillon Guadeloupe

## ✅ ÉTAPE 1 : Installer et Tester Localement

### Commandes à Exécuter

Ouvrez un terminal dans le dossier du projet et exécutez :

```bash
# 1. Installer toutes les dépendances
npm install

# 2. Lancer le serveur de développement
npm run dev
```

Le site sera accessible sur : **http://localhost:5173**

### Vérifications

- ✅ Toutes les pages s'affichent correctement
- ✅ La navigation fonctionne
- ✅ Les images se chargent
- ✅ Aucune erreur dans la console

---

## 📤 ÉTAPE 2 : Préparer pour GitHub

### Fichiers à Uploader sur GitHub

**INCLURE** ✅ :
```
✅ components/          (tout le dossier)
✅ pages/               (tout le dossier)
✅ public/              (tout le dossier)
✅ styles/              (tout le dossier)
✅ App.tsx
✅ main.tsx
✅ index.html
✅ package.json         (TRÈS IMPORTANT)
✅ vite.config.ts
✅ tsconfig.json
✅ .gitignore
✅ vercel.json
✅ LICENSE
✅ README.md
```

**NE PAS INCLURE** ❌ :
```
❌ node_modules/       (sera auto-installé)
❌ dist/               (sera auto-généré)

❌ Tous les fichiers .md de documentation SAUF :
   ✅ README.md
   ✅ DEPLOIEMENT_GITHUB.md (optionnel)
   ✅ GUIDE_DEPLOIEMENT_NOM_DE_DOMAINE.md (optionnel)
```

---

## 🌐 ÉTAPE 3 : Uploader sur GitHub (Simple)

### 3.1 Créer le Repository

1. Allez sur **https://github.com**
2. Cliquez sur **"+"** → **"New repository"**
3. **Nom** : `papillon-guadeloupe`
4. **Description** : `Site officiel de Papillon Guadeloupe SASU - Paysagiste en Guadeloupe`
5. **Public** ✅
6. **Create repository**

### 3.2 Uploader les Fichiers

1. Sur la page du repository, cliquez : **"uploading an existing file"**
2. **Sélectionnez** tous les fichiers à inclure (voir liste ci-dessus)
3. **Glissez-déposez** dans GitHub
4. Message de commit : `Initial commit - Site Papillon Guadeloupe`
5. **Commit changes**

⏱️ Attendez 1-2 minutes que tous les fichiers soient uploadés.

---

## 🚀 ÉTAPE 4 : Déployer sur Vercel

### 4.1 Créer un Compte Vercel

1. Allez sur **https://vercel.com**
2. **Sign Up** → **Continue with GitHub**
3. Autorisez Vercel

### 4.2 Déployer

1. **Dashboard Vercel** → **Add New...** → **Project**
2. Sélectionnez : **papillon-guadeloupe**
3. Cliquez : **Import**
4. Configuration (auto-détectée) :
   - Framework : **Vite** ✅
   - Build Command : `npm run build` ✅
   - Output Directory : `dist` ✅
5. Cliquez : **Deploy**
6. ⏱️ Attendez 2-3 minutes

### 4.3 Site En Ligne ! 🎉

Vous obtiendrez une URL : `https://papillon-guadeloupe.vercel.app`

---

## 🔗 ÉTAPE 5 : Ajouter un Nom de Domaine (Optionnel)

### Acheter un Domaine

**Recommandation** : OVH.com

1. Allez sur **https://www.ovh.com/fr/domaines/**
2. Cherchez : `papillon-guadeloupe`
3. Choisissez :
   - ⭐ `.fr` - 6-8€/an
   - 🇬🇵 `.gp` - 30-40€/an
   - 🌍 `.com` - 8-10€/an
4. Achetez

### Connecter à Vercel

**Dans Vercel** :
1. Projet → **Settings** → **Domains**
2. Ajoutez votre domaine : `papillon-guadeloupe.fr`
3. Vercel vous donne les DNS à configurer

**Dans OVH** :
1. **Noms de domaine** → Votre domaine → **Zone DNS**
2. Ajoutez les enregistrements DNS donnés par Vercel
3. Attendez 2-24h pour la propagation

---

## 📊 Résumé Ultra-Rapide

```
1️⃣ npm install && npm run dev       → Tester localement
2️⃣ Créer repository GitHub          → 3 min
3️⃣ Uploader les fichiers             → 5 min
4️⃣ Déployer sur Vercel               → 3 min
5️⃣ (Optionnel) Nom de domaine        → 24h

TOTAL : 15 min + attente DNS
COÛT : 0€ (gratuit) ou 6-8€/an (avec domaine)
```

---

## ✅ Checklist Finale

### Avant Upload GitHub
- [ ] `npm install` exécuté
- [ ] `npm run dev` fonctionne
- [ ] Toutes les pages testées
- [ ] node_modules/ exclu
- [ ] dist/ exclu

### Sur GitHub
- [ ] Repository créé
- [ ] Tous les fichiers uploadés
- [ ] package.json présent
- [ ] README.md visible

### Sur Vercel
- [ ] Compte créé avec GitHub
- [ ] Projet importé
- [ ] Déploiement réussi
- [ ] Site accessible en ligne
- [ ] Toutes les pages fonctionnent

### Domaine (Optionnel)
- [ ] Domaine acheté
- [ ] DNS configurés
- [ ] HTTPS actif

---

## 🆘 Commandes Utiles

```bash
# Installer les dépendances
npm install

# Lancer en développement
npm run dev

# Construire pour production
npm run build

# Prévisualiser le build
npm run preview

# Linter
npm run lint
```

---

## 📞 Support

Pour plus de détails, consultez :

- **`DEPLOIEMENT_GITHUB.md`** - Guide complet étape par étape
- **`GUIDE_DEPLOIEMENT_NOM_DE_DOMAINE.md`** - Guide nom de domaine
- **`INSTRUCTIONS_UPLOAD_GITHUB.md`** - Instructions détaillées
- **`README.md`** - Documentation du projet

---

## 🎯 Objectif Final

**Site accessible 24/7 sur votre propre nom de domaine :**

```
https://papillon-guadeloupe.fr
```

Avec :
- ✅ HTTPS sécurisé 🔒
- ✅ Responsive (mobile/tablette/desktop)
- ✅ Performance optimisée
- ✅ SEO configuré
- ✅ Hébergement gratuit

---

**🌴 PAPILLON GUADELOUPE SASU**  
Architecte paysagiste de jardins d'exception  
SIRET : 830 230 603 00011

**Prêt pour le déploiement !** 🚀
