# 🚀 Guide de Déploiement GitHub - Papillon Guadeloupe

Guide complet pour mettre votre code sur GitHub et déployer en ligne.

---

## 📋 ÉTAPE 1 : Créer un Compte GitHub

1. Allez sur **https://github.com**
2. Cliquez sur **"Sign up"** (S'inscrire)
3. Remplissez :
   - **Email** : Votre email professionnel
   - **Mot de passe** : Un mot de passe sécurisé
   - **Nom d'utilisateur** : Ex: `papillon-guadeloupe`
4. Vérifiez votre email
5. ✅ **Compte créé !**

---

## 📦 ÉTAPE 2 : Uploader le Code sur GitHub

### Méthode A : Via l'Interface GitHub (Plus Simple)

#### 1. Créer un Nouveau Repository

1. Connectez-vous à GitHub
2. Cliquez sur le **"+"** en haut à droite
3. Sélectionnez **"New repository"**
4. Remplissez :
   - **Repository name** : `papillon-guadeloupe` 
   - **Description** : `Site web officiel de Papillon Guadeloupe SASU - Paysagiste en Guadeloupe`
   - **Public** ✅ (pour pouvoir déployer gratuitement)
   - **Add a README** ❌ (on a déjà le nôtre)
5. Cliquez sur **"Create repository"**

#### 2. Uploader les Fichiers

**Option Simple : Drag & Drop**

1. Sur la page du repository, cliquez sur **"uploading an existing file"**
2. **Glissez-déposez** TOUS les fichiers de votre projet :
   - ✅ Tous les fichiers `.tsx`, `.ts`, `.json`, `.css`, etc.
   - ✅ Tous les dossiers (`components/`, `pages/`, `public/`, etc.)
   - ❌ **NE PAS UPLOADER** : `node_modules/`, `dist/`, `.DS_Store`
3. Ajoutez un message : `Initial commit - Site Papillon Guadeloupe`
4. Cliquez sur **"Commit changes"**
5. ⏱️ **Attendez 1-2 minutes** que tous les fichiers soient uploadés

✅ **Votre code est maintenant sur GitHub !**

---

### Méthode B : Via Git en Ligne de Commande (Avancé)

Si vous êtes à l'aise avec le terminal :

```bash
# 1. Initialiser Git dans votre projet
cd /chemin/vers/papillon-guadeloupe
git init

# 2. Ajouter tous les fichiers
git add .

# 3. Créer le premier commit
git commit -m "Initial commit - Site Papillon Guadeloupe"

# 4. Ajouter le repository distant
git remote add origin https://github.com/VOTRE_USERNAME/papillon-guadeloupe.git

# 5. Pousser le code
git push -u origin main
```

---

## 🌐 ÉTAPE 3 : Déployer sur Vercel

### Pourquoi Vercel ?

- ✅ **100% Gratuit** pour les sites React/Vite
- ✅ **Déploiement en 2 minutes**
- ✅ **HTTPS automatique** (site sécurisé 🔒)
- ✅ **Mises à jour automatiques** quand vous modifiez GitHub
- ✅ **Très facile** à configurer

### Instructions Détaillées

#### 1. Créer un Compte Vercel

1. Allez sur **https://vercel.com**
2. Cliquez sur **"Sign Up"**
3. Choisissez **"Continue with GitHub"**
4. Autorisez Vercel à accéder à votre GitHub
5. ✅ **Compte créé !**

#### 2. Importer le Projet

1. Sur le dashboard Vercel, cliquez sur **"Add New..."**
2. Sélectionnez **"Project"**
3. Vous verrez votre repository **"papillon-guadeloupe"**
4. Cliquez sur **"Import"**

#### 3. Configuration (Automatique)

Vercel détecte automatiquement :
- ✅ **Framework Preset** : Vite
- ✅ **Build Command** : `npm run build`
- ✅ **Output Directory** : `dist`
- ✅ **Install Command** : `npm install`

**Vous n'avez RIEN à modifier !**

#### 4. Déployer

1. Cliquez sur **"Deploy"**
2. ⏱️ **Attendez 2-3 minutes**
3. Vercel va :
   - Installer les dépendances
   - Construire votre site
   - Le mettre en ligne

#### 5. C'est En Ligne ! 🎉

Une fois terminé, vous verrez :
- ✅ **"Congratulations!"**
- 🌐 Une URL temporaire : `https://papillon-guadeloupe.vercel.app`

**Cliquez sur l'URL pour voir votre site en ligne !**

---

## 🔗 ÉTAPE 4 : Ajouter un Nom de Domaine Personnalisé

### Acheter un Nom de Domaine

**Recommandation : OVH.com**

1. Allez sur **https://www.ovh.com/fr/domaines/**
2. Cherchez : `papillon-guadeloupe`
3. Choisissez l'extension :
   - ⭐ `.fr` - 6-8€/an (Recommandé)
   - 🇬🇵 `.gp` - 30-40€/an (Guadeloupe)
   - 🌍 `.com` - 8-10€/an (International)
4. Ajoutez au panier et payez
5. ✅ **Vous êtes propriétaire du domaine !**

### Connecter le Domaine à Vercel

#### Dans Vercel :

1. Allez dans votre projet sur Vercel
2. Cliquez sur **"Settings"** (Paramètres)
3. Dans le menu de gauche, cliquez sur **"Domains"**
4. Tapez votre domaine : `papillon-guadeloupe.fr`
5. Cliquez sur **"Add"**
6. Vercel vous donne les **DNS à configurer**

**Notez ces informations** (exemple) :
```
Type: A
Name: @
Value: 76.76.21.21

Type: CNAME
Name: www
Value: cname.vercel-dns.com
```

#### Dans OVH :

1. Connectez-vous à **https://www.ovh.com/manager/**
2. Allez dans **"Noms de domaine"**
3. Cliquez sur votre domaine (`papillon-guadeloupe.fr`)
4. Cliquez sur l'onglet **"Zone DNS"**
5. Cliquez sur **"Ajouter une entrée"**

**Ajoutez 2 entrées** :

**Entrée 1 (Domaine principal) :**
- Type : `A`
- Sous-domaine : *laisser vide* ou `@`
- Cible : `76.76.21.21` (l'IP donnée par Vercel)
- TTL : Auto

**Entrée 2 (Sous-domaine www) :**
- Type : `CNAME`
- Sous-domaine : `www`
- Cible : `cname.vercel-dns.com` (donné par Vercel)
- TTL : Auto

6. Validez les deux entrées

#### Attendre la Propagation DNS

⏱️ **Temps d'attente : 2-24 heures** (souvent 2-6h)

**Vérifier l'état** :
1. Allez sur **https://dnschecker.org**
2. Entrez votre domaine : `papillon-guadeloupe.fr`
3. Vérifiez que ça se propage dans le monde

**Une fois propagé** :
- ✅ Votre site est accessible sur `https://papillon-guadeloupe.fr`
- 🔒 HTTPS automatiquement activé par Vercel
- 🎉 **Votre site professionnel est en ligne !**

---

## 🔄 ÉTAPE 5 : Mettre à Jour le Site (Après Modifications)

### Si vous avez modifié des fichiers localement :

#### Méthode Simple (Interface GitHub)

1. Allez sur votre repository GitHub
2. Naviguez jusqu'au fichier à modifier
3. Cliquez sur le **crayon** ✏️ (Edit)
4. Faites vos modifications
5. En bas, cliquez sur **"Commit changes"**
6. ⏱️ **Vercel redéploie automatiquement en 1-2 minutes !**

#### Méthode Git (Ligne de commande)

```bash
# 1. Après avoir modifié vos fichiers
git add .

# 2. Créer un commit
git commit -m "Description de vos modifications"

# 3. Pousser sur GitHub
git push origin main

# 4. Vercel détecte et redéploie automatiquement !
```

**C'est magique :** Chaque fois que vous modifiez GitHub, Vercel met à jour votre site automatiquement ! 🚀

---

## ✅ Checklist de Déploiement

Cochez au fur et à mesure :

### Préparation
- [ ] Compte GitHub créé
- [ ] Tous les fichiers du projet prêts
- [ ] Fichier `.gitignore` présent (pour exclure node_modules)

### Upload GitHub
- [ ] Repository créé sur GitHub
- [ ] Tous les fichiers uploadés
- [ ] README.md visible sur GitHub
- [ ] Code accessible en ligne sur GitHub

### Déploiement Vercel
- [ ] Compte Vercel créé avec GitHub
- [ ] Projet importé dans Vercel
- [ ] Déploiement réussi
- [ ] Site accessible sur `.vercel.app`
- [ ] Toutes les pages fonctionnent
- [ ] Images affichées correctement
- [ ] Formulaire de contact fonctionne

### Nom de Domaine (Optionnel)
- [ ] Domaine acheté (OVH)
- [ ] Domaine ajouté dans Vercel
- [ ] DNS configurés chez OVH
- [ ] Propagation DNS complète
- [ ] Site accessible sur votre domaine
- [ ] HTTPS activé automatiquement

---

## 📊 Fichiers Importants à Vérifier

Avant d'uploader sur GitHub, assurez-vous que ces fichiers sont présents :

### Configuration
- ✅ `package.json` - Dépendances du projet
- ✅ `vite.config.ts` - Configuration Vite
- ✅ `tsconfig.json` - Configuration TypeScript
- ✅ `.gitignore` - Fichiers à exclure de Git

### Code Source
- ✅ `index.html` - Point d'entrée HTML
- ✅ `main.tsx` - Point d'entrée React
- ✅ `App.tsx` - Composant principal
- ✅ `components/` - Tous les composants
- ✅ `pages/` - Toutes les pages
- ✅ `styles/globals.css` - Styles globaux

### Fichiers Publics
- ✅ `public/sitemap.xml` - Plan du site
- ✅ `public/robots.txt` - SEO
- ✅ `public/manifest.json` - PWA
- ✅ `public/images/README.md` - Instructions images

### Documentation
- ✅ `README.md` - Documentation principale

### À NE PAS Uploader
- ❌ `node_modules/` - Dépendances (auto-installées)
- ❌ `dist/` - Build de production (auto-généré)
- ❌ `.env` - Variables d'environnement (si présent)
- ❌ `.DS_Store` - Fichiers macOS

---

## 🆘 Problèmes Courants

### "Le site ne se déploie pas sur Vercel"

**Solution :**
1. Vérifiez que `package.json` est présent dans le repository
2. Vérifiez que `vite.config.ts` est présent
3. Dans Vercel, allez dans **"Deployments"** → Cliquez sur le dernier déploiement
4. Regardez les **logs d'erreur**
5. Si erreur TypeScript : vérifiez vos imports

### "Les images ne s'affichent pas"

**Solution :**
1. Vérifiez que le dossier `public/images/` est uploadé
2. Vérifiez que `ImageConfig.tsx` contient les bonnes URLs
3. Si vous utilisez Unsplash, vérifiez que les URLs sont valides

### "Page 404 sur Vercel"

**Solution :**
1. Vercel détecte automatiquement React Router
2. Si problème, ajoutez un fichier `vercel.json` :

```json
{
  "rewrites": [
    { "source": "/(.*)", "destination": "/" }
  ]
}
```

### "Le formulaire de contact ne fonctionne pas"

**Note :** Le formulaire utilise actuellement `mailto:`. Pour un vrai formulaire :

**Option 1 : Formspree (Gratuit)**
1. Créez un compte sur https://formspree.io
2. Créez un formulaire
3. Récupérez l'URL du endpoint
4. Modifiez `Contact.tsx` pour envoyer à Formspree

**Option 2 : EmailJS (Gratuit)**
1. Créez un compte sur https://emailjs.com
2. Configurez un service email
3. Intégrez dans `Contact.tsx`

---

## 📞 Support

### Ressources Utiles
- **Documentation Vercel** : https://vercel.com/docs
- **Documentation Vite** : https://vitejs.dev
- **Documentation React Router** : https://reactrouter.com

### Communauté
- **GitHub Discussions** : Posez vos questions dans votre repository
- **Stack Overflow** : Recherchez des solutions
- **Discord React** : Communauté React francophone

---

## 🎉 Résumé des Coûts

| Service | Prix | Fréquence |
|---------|------|-----------|
| **GitHub** | 0€ | Gratuit |
| **Vercel (Hébergement)** | 0€ | Gratuit |
| **Nom de domaine .fr** | 6-8€ | Par an |
| **Certificat SSL/HTTPS** | 0€ | Gratuit (Vercel) |
| **Formspree (Formulaire)** | 0€ | Gratuit (50 emails/mois) |

**💰 Total : 0€** (avec URL Vercel) ou **6-8€/an** (avec domaine personnalisé)

---

## 🚀 Prochaines Étapes Après Déploiement

1. **SEO**
   - Inscrivez votre site sur Google Search Console
   - Soumettez votre sitemap.xml

2. **Analytics**
   - Ajoutez Google Analytics (gratuit)
   - Suivez vos visiteurs

3. **Performance**
   - Testez avec Google PageSpeed Insights
   - Optimisez si nécessaire

4. **Communication**
   - Partagez votre nouveau site sur les réseaux sociaux
   - Mettez à jour vos cartes de visite
   - Ajoutez l'URL dans vos signatures email

---

**🌴 Bon déploiement !**

Votre site professionnel sera bientôt accessible 24/7 partout dans le monde ! 🌍

---

**Dernière mise à jour** : Octobre 2025
**Créé pour** : PAPILLON GUADELOUPE SASU
