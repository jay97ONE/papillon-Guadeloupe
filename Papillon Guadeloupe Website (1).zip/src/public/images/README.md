# Organisation des Médias - Papillon Guadeloupe

## Structure complète recommandée :

```
/public/
├── images/
│   ├── hero/
│   │   ├── hero-main.jpg (1920x1080) - Image principale d'accueil
│   │   └── hero-mobile.jpg (750x1334) - Version mobile
│   ├── logo/
│   │   ├── papillon-logo.png - Logo principal
│   │   ├── papillon-logo-white.png - Logo blanc
│   │   └── favicon.ico - Icône navigateur
│   ├── portfolio/
│   │   ├── projet-01-avant.jpg
│   │   ├── projet-01-apres.jpg
│   │   ├── projet-01-thumb.jpg (400x300) - Miniature
│   │   ├── projet-01-poster.jpg - Image de couverture vidéo
│   │   ├── projet-02-avant.jpg
│   │   ├── projet-02-apres.jpg
│   │   └── ... (jusqu'à 6 projets)
│   ├── services/
│   │   ├── consultation.jpg - Visite conseil
│   │   ├── conception-3d.jpg - Conception 3D
│   │   ├── realisation.jpg - Réalisation
│   │   └── maitrise-oeuvre.jpg - Maîtrise d'œuvre
│   ├── processus/
│   │   ├── analyse-terrain.jpg - Étape 1
│   │   ├── conception-3d.jpg - Étape 2
│   │   └── accompagnement.jpg - Étape 3
│   └── testimonials/
│       ├── marie-d-poster.jpg
│       └── jean-luc-p-poster.jpg
└── videos/
    ├── papillon-presentation.mp4 - Vidéo principale (30-60 sec)
    ├── portfolio/
    │   ├── projet-01-transformation.mp4 - Avant/après animé
    │   ├── projet-02-transformation.mp4
    │   └── projet-03-transformation.mp4
    ├── processus/
    │   ├── visite-3d-exemple.mp4 - Démonstration 3D
    │   └── timelapse-realisation.mp4 - Réalisation accélérée
    └── testimonials/
        ├── client-marie-d.mp4 - Témoignage vidéo
        └── client-jean-luc-p.mp4
```

## Recommandations techniques :

### Images :
- **Format** : JPG pour les photos, PNG pour les logos avec transparence
- **Taille** : Max 2MB par image pour un chargement rapide
- **Dimensions** :
  - Hero : 1920x1080px (desktop) + 750x1334px (mobile)
  - Portfolio : 800x600px minimum
  - Thumbnails : 400x300px
  - Services : 600x400px minimum
- **Optimisation** : Utilisez TinyPNG.com ou Squoosh.app

### Vidéos :
- **Format** : MP4 (H.264/AVC)
- **Taille** : Max 50MB par vidéo
- **Résolution** : 
  - Présentation : 1920x1080 (Full HD)
  - Portfolio : 1280x720 (HD)
  - Témoignages : 1280x720 (HD)
- **Durée recommandée** :
  - Présentation : 30-60 secondes
  - Portfolio : 10-20 secondes
  - Témoignages : 1-2 minutes
- **Compression** : Utilisez HandBrake ou Clipchamp

## Nommage :

- **Conventions** : 
  - Pas d'espaces, utilisez des tirets
  - Tout en minuscules
  - Descriptif et numéroté
- **Exemples** :
  - `projet-01-avant.jpg`
  - `villa-moderne-apres.jpg`
  - `transformation-jardin-tropical.mp4`

## Types de contenus à privilégier :

### Images :
- **Avant/après** : Transformations spectaculaires
- **Détails** : Végétation, matériaux, aménagements
- **Ambiances** : Éclairage, saisons, usage des espaces
- **Techniques** : Plans 3D, dessins, croquis

### Vidéos :
- **Timelapse** : Réalisations de A à Z
- **Tours 3D** : Projets avant réalisation
- **Drone** : Vues aériennes des aménagements
- **Témoignages** : Clients satisfaits authentiques

## Checklist de qualité :

- [ ] Images nettes et bien cadrées
- [ ] Éclairage naturel privilégié
- [ ] Végétation en bon état
- [ ] Pas d'éléments perturbateurs (poubelles, voitures, etc.)
- [ ] Respect de la vie privée (floutage si nécessaire)
- [ ] Vidéos stables (trépied ou stabilisateur)
- [ ] Son de qualité pour les témoignages