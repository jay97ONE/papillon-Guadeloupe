# ⚡ Guide de Finalisation Express (5-10 minutes)

## 🎯 Objectif : Passer de 95% à 100% en moins de 10 minutes

---

## ✅ ÉTAPE 1 : Coordonnées (2 minutes)

### Ouvrir le fichier `CONFIG_ENTREPRISE.md`
Remplir les 3 informations essentielles :

```
✏️ Email : _______________________________
✏️ Téléphone : _______________________________
✏️ Domaine : _______________________________
```

### Faire les remplacements globaux

**Dans VS Code / Éditeur de texte** :

1. **Ctrl+Shift+H** (Windows) ou **Cmd+Shift+H** (Mac)

2. **Remplacer l'email** :
   ```
   Rechercher : contact@papillon-guadeloupe.com
   Remplacer par : [VOTRE EMAIL]
   Cliquer sur : Remplacer tout
   ```

3. **Remplacer le téléphone** :
   ```
   Rechercher : +590 690 XX XX XX
   Remplacer par : [VOTRE TÉLÉPHONE]
   Cliquer sur : Remplacer tout
   ```

4. **Remplacer le domaine** :
   ```
   Rechercher : papillon-guadeloupe.com
   Remplacer par : [VOTRE DOMAINE]
   Cliquer sur : Remplacer tout
   ```

✅ **Résultat** : Toutes vos coordonnées sont maintenant réelles !

---

## ✅ ÉTAPE 2 : Mentions Légales (1 minute)

Ouvrir `/pages/MentionsLegales.tsx`

**Compléter rapidement** (chercher les `[...]`) :

```tsx
// Ligne ~22
<strong className="block mb-2">[Nom du directeur]</strong>
// → Remplacer par votre nom

// Ligne ~31
<strong>[Nom de l'hébergeur]</strong><br />
// → Remplacer par "Netlify" ou "Vercel" ou votre hébergeur
```

✅ **Résultat** : Page Mentions Légales conforme !

---

## ✅ ÉTAPE 3 : Favicon Simple (2 minutes)

### Option rapide : Emoji Papillon

**Méthode 1 : Image PNG simple**

1. **Créer un fichier PNG** :
   - Aller sur https://favicon.io/emoji-favicons/
   - Chercher "🦋" ou choisir un emoji
   - Télécharger le package
   - Copier tous les fichiers dans `/public/`

2. **Ou utiliser Canva Express** :
   - https://www.canva.com/
   - Créer 512x512px
   - Fond vert + emoji 🦋
   - Télécharger PNG
   - Aller sur https://realfavicongenerator.net/
   - Upload + Générer + Télécharger dans `/public/`

✅ **Résultat** : Favicon fonctionnel !

---

## ✅ ÉTAPE 4 : Images Open Graph (3 minutes)

### Template ultra-rapide sur Canva

1. **Aller sur** : https://www.canva.com/
2. **Créer** : "Facebook Post" (1200x630px)
3. **Design minimaliste** :
   ```
   Fond : Vert #16a34a avec dégradé
   Texte 1 (grand) : "Papillon Guadeloupe"
   Texte 2 (moyen) : "Architecte Paysagiste"
   Emoji : 🦋 en haut
   ```
4. **Télécharger** : 
   - En JPG
   - Nommer `og-image.jpg`
5. **Dupliquer pour Twitter** :
   - Redimensionner en 1200x600px
   - Nommer `twitter-image.jpg`
6. **Placer** les 2 fichiers dans `/public/`

✅ **Résultat** : Partages sociaux professionnels !

---

## ✅ ÉTAPE 5 : Sitemap (30 secondes)

Le fichier `/public/sitemap.xml` existe déjà !

**Juste à faire** : Remplacer le domaine

Ouvrir `/public/sitemap.xml` et faire :
```
Rechercher : papillon-guadeloupe.com
Remplacer par : [VOTRE DOMAINE]
Remplacer tout
```

✅ **Résultat** : SEO optimisé !

---

## 🧪 ÉTAPE 6 : Test & Build (2 minutes)

### Tester en local

```bash
# Terminal 1
npm run dev
```

Ouvrir http://localhost:3000 et vérifier :
- ✅ Le favicon apparaît dans l'onglet
- ✅ Toutes les pages se chargent
- ✅ Les formulaires fonctionnent
- ✅ Le site est beau sur mobile (F12 → Mode mobile)

### Créer le build de production

```bash
# Arrêter le serveur dev (Ctrl+C)
npm run build
```

**Résultat attendu** :
```
✓ built in 3.45s
```

Si erreurs → Corriger et relancer

✅ **Résultat** : Site prêt à déployer !

---

## 🚀 ÉTAPE 7 : Déploiement (5 minutes)

### Sur Netlify (GRATUIT et SIMPLE)

1. **Aller sur** : https://app.netlify.com/

2. **Se connecter** : 
   - Avec GitHub, GitLab ou Email

3. **Déployer** :
   - Cliquer sur "Add new site"
   - Choisir "Deploy manually"
   - **Drag & drop** le dossier `/dist/` complet
   - Attendre 30 secondes

4. **Configurer** :
   - Site Settings → Change site name → [votre-nom]
   - Domain Settings → Add custom domain → [votre-domaine.com]
   - SSL/TLS → Activer HTTPS (automatique)

5. **Configurer les redirects** :
   - Site Settings → Build & deploy → Redirects
   - Ajouter : `/* /index.html 200`

✅ **Résultat** : Site en ligne ! 🎉

**URL temporaire** : `https://[votre-nom].netlify.app`

---

## 📋 CHECKLIST FINALE

Avant de valider, cocher :

### Contenu
- [ ] Email réel partout
- [ ] Téléphone réel partout
- [ ] Mentions légales complétées
- [ ] Domaine mis à jour

### Assets
- [ ] Favicon visible dans l'onglet
- [ ] Images Open Graph créées

### Technique
- [ ] `npm run build` sans erreur
- [ ] Site testé en local
- [ ] Sitemap.xml à jour

### Déploiement
- [ ] Site déployé sur Netlify/Vercel
- [ ] HTTPS activé
- [ ] Toutes les pages accessibles
- [ ] Formulaires testés

---

## 🎉 VOUS AVEZ TERMINÉ !

Votre site **Papillon Guadeloupe Création** est maintenant :

✅ **100% complet**  
✅ **En ligne**  
✅ **Opérationnel**  
✅ **Professionnel**

---

## 📱 PROCHAINES ÉTAPES (Optionnel)

### Jour 1 après mise en ligne
- [ ] Tester tous les liens sur mobile
- [ ] Envoyer un email de test depuis chaque formulaire
- [ ] Partager sur Facebook/WhatsApp pour tester Open Graph
- [ ] Faire tester par 2-3 personnes

### Semaine 1
- [ ] Soumettre à Google Search Console
- [ ] Créer Google My Business
- [ ] Partager sur réseaux sociaux
- [ ] Demander premiers avis clients

### Mois 1
- [ ] Remplacer 5 images Unsplash par photos réelles
- [ ] Ajouter 2-3 nouveaux projets au portfolio
- [ ] Analyser Google Analytics
- [ ] Optimiser selon retours utilisateurs

---

## 🆘 PROBLÈME ?

### Le site ne build pas
```bash
# Vérifier les erreurs
npm run build

# Si erreur TypeScript, corriger le fichier indiqué
# Puis relancer le build
```

### Le favicon ne s'affiche pas
```bash
# Vider le cache
Ctrl+Shift+Delete (ou Cmd+Shift+Delete)
Cocher "Images en cache"
Vider
Recharger (Ctrl+F5)
```

### Les formulaires ne fonctionnent pas
```bash
# Sur Netlify :
# 1. Aller dans Forms
# 2. Activer "Form detection"
# 3. Redéployer le site
```

### Le site est lent
```bash
# Compresser les images
# Aller sur : https://tinypng.com/
# Upload vos images
# Télécharger versions compressées
# Remplacer dans le projet
```

---

## 🏁 FÉLICITATIONS !

Temps total : **10 minutes max**  
Résultat : **Site 100% professionnel en ligne**

Vous pouvez maintenant :
- 📧 Recevoir des demandes de devis
- 📱 Partager votre site web
- 🌐 Être trouvé sur Google
- 💼 Présenter votre portfolio

**Développé avec ❤️ pour Papillon Guadeloupe Création**

---

**Date** : 14 décembre 2024  
**Version** : 1.0.0  
**Statut** : Production Ready ✅
