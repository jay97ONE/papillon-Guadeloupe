# 🔄 Script de remplacement rapide des coordonnées (Windows PowerShell)
# Pour Papillon Guadeloupe Création
# Usage : .\SCRIPT_REMPLACEMENT_RAPIDE.ps1

Write-Host "🦋 Script de finalisation Papillon Guadeloupe" -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host ""

# Demander les informations
Write-Host "📧 Entrez votre email réel :" -ForegroundColor Yellow
$NEW_EMAIL = Read-Host "> "

Write-Host "📱 Entrez votre téléphone réel (ex: +590 690 12 34 56) :" -ForegroundColor Yellow
$NEW_PHONE = Read-Host "> "

Write-Host "🌐 Entrez votre nom de domaine (ex: monsite.com) :" -ForegroundColor Yellow
$NEW_DOMAIN = Read-Host "> "

Write-Host ""
Write-Host "Vérification des informations :"
Write-Host "------------------------------"
Write-Host "Email    : $NEW_EMAIL"
Write-Host "Téléphone: $NEW_PHONE"
Write-Host "Domaine  : $NEW_DOMAIN"
Write-Host ""
Write-Host "Ces informations sont-elles correctes ? (o/n)" -ForegroundColor Yellow
$CONFIRM = Read-Host "> "

if ($CONFIRM -ne "o" -and $CONFIRM -ne "O") {
    Write-Host "❌ Annulé. Relancez le script avec les bonnes informations." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "🔄 Remplacement en cours..." -ForegroundColor Cyan
Write-Host ""

# Fonction pour remplacer dans tous les fichiers
function Replace-InFiles {
    param(
        [string]$Search,
        [string]$Replace,
        [string]$Description
    )
    
    $extensions = @("*.tsx", "*.ts", "*.html", "*.md", "*.xml", "*.json")
    $excludePaths = @("node_modules", ".git", "dist")
    
    foreach ($ext in $extensions) {
        Get-ChildItem -Path . -Filter $ext -Recurse -File | 
            Where-Object { 
                $exclude = $false
                foreach ($path in $excludePaths) {
                    if ($_.FullName -like "*\$path\*") {
                        $exclude = $true
                        break
                    }
                }
                -not $exclude
            } | 
            ForEach-Object {
                $content = Get-Content $_.FullName -Raw
                if ($content -match [regex]::Escape($Search)) {
                    $content = $content -replace [regex]::Escape($Search), $Replace
                    Set-Content -Path $_.FullName -Value $content -NoNewline
                }
            }
    }
    
    Write-Host "✓ $Description" -ForegroundColor Green
}

# Effectuer les remplacements
Replace-InFiles -Search "contact@papillon-guadeloupe.com" -Replace $NEW_EMAIL -Description "Email mis à jour"
Replace-InFiles -Search "+590 690 XX XX XX" -Replace $NEW_PHONE -Description "Téléphone mis à jour"
Replace-InFiles -Search "papillon-guadeloupe.com" -Replace $NEW_DOMAIN -Description "Domaine mis à jour"

Write-Host ""
Write-Host "✅ Remplacement terminé !" -ForegroundColor Green
Write-Host ""
Write-Host "Prochaines étapes :"
Write-Host "1. Vérifier les fichiers modifiés"
Write-Host "2. Compléter pages/MentionsLegales.tsx"
Write-Host "3. Générer les favicons (voir INSTRUCTIONS_FAVICONS.md)"
Write-Host "4. Lancer npm run build"
Write-Host ""
Write-Host "🚀 Bonne finalisation !"
