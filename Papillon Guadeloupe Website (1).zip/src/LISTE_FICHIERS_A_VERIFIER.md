# 📝 Liste des fichiers à vérifier avant déploiement

## ✅ Fichiers contenant les coordonnées

### 📧 Email `contact@papillon-guadeloupe.com`

**À remplacer dans :**

1. ✅ `/components/Layout.tsx`
   - Ligne ~300 : `const CONTACT_EMAIL = "..."`
   - Ligne ~300 : Lien `mailto:` dans le footer

2. ✅ `/pages/Contact.tsx`
   - Ligne ~9 : `const CONTACT_EMAIL = "..."`

3. ✅ `/pages/MentionsLegales.tsx`
   - Plusieurs occurrences dans le contenu
   - Section "Éditeur du site"
   - Section "Contact"

4. ✅ `/index.html`
   - Meta tags (si présent)

5. ✅ `/README.md`
   - Section "Contact"
   - Section déploiement

---

### 📱 Téléphone `+590 690 XX XX XX`

**À remplacer dans :**

1. ✅ `/components/Layout.tsx`
   - Ligne ~293 : `const PHONE = "..."`
   - Ligne ~294 : Lien `tel:` dans le footer

2. ✅ `/pages/Contact.tsx`
   - Ligne ~10 : `const PHONE = "..."`

3. ✅ `/pages/EntretienPaysager.tsx`
   - Section CTA finale (~ligne 538)
   - Texte : "Contactez-nous directement au..."

4. ✅ `/pages/LocationMotoculteur.tsx`
   - Section CTA finale (~ligne 677)
   - Texte : "Contactez-nous au..."

5. ✅ `/pages/MentionsLegales.tsx`
   - Section "Éditeur du site"
   - Section "Contact"

6. ✅ `/README.md`
   - Section "Contact"

---

### 🌐 Domaine `papillon-guadeloupe.com`

**À remplacer dans :**

1. ✅ `/index.html`
   - Meta tag `og:url`
   - Meta tag `twitter:url`
   - Meta tag `og:image`
   - Meta tag `twitter:image`

2. ✅ `/public/robots.txt`
   - Ligne "Sitemap: https://..."

3. ✅ `/public/sitemap.xml`
   - Toutes les balises `<loc>`
   - 11 URLs à mettre à jour

4. ✅ `/pages/MentionsLegales.tsx`
   - Section hébergement (si URL mentionnée)

5. ✅ `/README.md`
   - Section "Contact"
   - Section "Déploiement"
   - Exemples d'URLs

---

## ⚠️ Fichiers nécessitant une action manuelle

### 1. `/pages/MentionsLegales.tsx`

**Lignes à compléter :**

```tsx
// Ligne ~22-28
<strong className="block mb-2">Papillon Guadeloupe Création</strong>
<p className="text-muted-foreground">
  Architecte paysagiste de jardins d'exception<br />
  Guadeloupe, Antilles françaises<br />
  <br />
  Email : <a href="mailto:contact@papillon-guadeloupe.com" ...>
  Téléphone : <a href="tel:+590690XXXXXX" ...>
</p>

// → Remplacer les coordonnées ci-dessus

// Ligne ~30-34
<strong className="block mb-2">Directeur de publication</strong>
<p className="text-muted-foreground">
  [Nom du directeur]<br />  ← REMPLACER ICI
  Gérant de Papillon Guadeloupe Création
</p>

// Ligne ~41-46
<p className="text-muted-foreground">
  Ce site est hébergé par :<br />
  <strong>[Nom de l'hébergeur]</strong><br />  ← REMPLACER ICI
  [Adresse de l'hébergeur]<br />  ← REMPLACER ICI
  Téléphone : [Téléphone hébergeur]  ← REMPLACER ICI
</p>
```

**Informations à ajouter :**
- Nom du directeur/gérant
- Nom de l'hébergeur (ex: "Netlify, Inc." ou "OVH")
- Adresse de l'hébergeur
- SIRET/SIREN si applicable

---

### 2. `/public/manifest.json`

**Vérifier/Personnaliser :**

```json
{
  "name": "Papillon Guadeloupe Création",  ← OK
  "short_name": "Papillon GLP",  ← Personnaliser si souhaité
  "description": "Architecte paysagiste...",  ← OK
  "start_url": "/",  ← OK
  "theme_color": "#16a34a"  ← OK (vert du site)
}
```

**Action :** Généralement OK, mais vous pouvez changer `short_name`

---

### 3. `/index.html`

**Vérifier ces sections :**

```html
<!-- SEO Meta Tags -->
<title>Papillon Guadeloupe Création - ...</title>  ← OK
<meta name="description" content="..." />  ← OK ou personnaliser
<meta name="keywords" content="..." />  ← Ajouter mots-clés locaux

<!-- Open Graph -->
<meta property="og:url" content="https://papillon-guadeloupe.com/" />  ← DOMAINE
<meta property="og:image" content="https://papillon-guadeloupe.com/og-image.jpg" />  ← DOMAINE

<!-- Twitter -->
<meta property="twitter:url" content="https://papillon-guadeloupe.com/" />  ← DOMAINE
<meta property="twitter:image" content="https://papillon-guadeloupe.com/twitter-image.jpg" />  ← DOMAINE
```

---

## 🎨 Assets graphiques à créer

### Dans `/public/` - MANQUANTS

**Favicons** :
- [ ] `favicon.svg` (ou `favicon.ico`)
- [ ] `favicon-16x16.png`
- [ ] `favicon-32x32.png`
- [ ] `favicon-192x192.png`
- [ ] `favicon-512x512.png`
- [ ] `apple-touch-icon.png`

**Images réseaux sociaux** :
- [ ] `og-image.jpg` (1200x630px)
- [ ] `twitter-image.jpg` (1200x600px)

**Instructions** : Voir `/public/INSTRUCTIONS_FAVICONS.md`

---

## 🔍 Vérification rapide

### Méthode 1 : Recherche globale dans l'éditeur

**Dans VS Code :**
1. `Ctrl+Shift+F` (ou `Cmd+Shift+F` sur Mac)
2. Rechercher : `contact@papillon-guadeloupe.com`
3. Vérifier qu'il ne reste aucune occurrence

Répéter pour :
- `+590 690 XX XX XX`
- `papillon-guadeloupe.com`
- `[Nom du directeur]`
- `[Nom de l'hébergeur]`

### Méthode 2 : Ligne de commande

**Linux/Mac** :
```bash
# Chercher email
grep -r "contact@papillon-guadeloupe.com" . --exclude-dir={node_modules,dist,.git}

# Chercher téléphone
grep -r "+590 690 XX XX XX" . --exclude-dir={node_modules,dist,.git}

# Chercher domaine
grep -r "papillon-guadeloupe.com" . --exclude-dir={node_modules,dist,.git}
```

**Windows PowerShell** :
```powershell
# Chercher email
Select-String -Path . -Pattern "contact@papillon-guadeloupe.com" -Recurse -Exclude node_modules,dist,.git

# Chercher téléphone
Select-String -Path . -Pattern "\+590 690 XX XX XX" -Recurse -Exclude node_modules,dist,.git
```

---

## ✅ Checklist de validation

### Avant le build

- [ ] Tous les emails remplacés
- [ ] Tous les téléphones remplacés
- [ ] Tous les domaines remplacés
- [ ] Mentions légales complétées (directeur + hébergeur)
- [ ] Favicons créés et placés dans `/public/`
- [ ] Images OG créées et placées dans `/public/`
- [ ] `sitemap.xml` mis à jour avec bon domaine

### Test local

```bash
npm run dev
```

- [ ] Site charge sans erreur
- [ ] Favicon visible dans l'onglet
- [ ] Footer affiche bonnes coordonnées
- [ ] Page contact affiche bon email/téléphone
- [ ] Mentions légales complètes
- [ ] Formulaires fonctionnels

### Build

```bash
npm run build
```

- [ ] Build réussit sans erreur
- [ ] Dossier `dist/` créé
- [ ] Fichiers favicon présents dans `dist/`

### Après déploiement

- [ ] Site accessible sur le bon domaine
- [ ] HTTPS actif (cadenas vert)
- [ ] Partage Facebook → Bon aperçu avec og-image
- [ ] Partage Twitter → Bon aperçu avec twitter-image
- [ ] Google "site:votre-domaine.com" après 24-48h

---

## 🚨 Erreurs fréquentes

### "Build failed: Cannot find module"
**Solution** : `npm install` puis `npm run build`

### "Favicon ne s'affiche pas"
**Solution** : Vider cache navigateur (Ctrl+Shift+Delete)

### "Images Open Graph ne s'affichent pas"
**Solution** : 
1. Attendre 24h (cache réseaux sociaux)
2. Utiliser https://developers.facebook.com/tools/debug/

### "Formulaires ne fonctionnent pas en production"
**Solution** : Configurer Netlify Forms ou Formspree

---

## 💾 Sauvegarde

Avant de déployer, faire une sauvegarde :

```bash
# Créer une archive
tar -czf papillon-guadeloupe-backup-$(date +%Y%m%d).tar.gz .

# Ou sur Windows
Compress-Archive -Path . -DestinationPath papillon-guadeloupe-backup.zip
```

---

**Dernière mise à jour** : 14 décembre 2024  
**Temps estimé** : 15 minutes pour tout vérifier
