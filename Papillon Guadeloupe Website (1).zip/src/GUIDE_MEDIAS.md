# 📸 Guide Complet - Médias Papillon Guadeloupe

## 🎯 Objectif
Ce guide vous explique comment organiser et utiliser les images et vidéos pour votre site Papillon Guadeloupe.

## 📁 Structure des Fichiers

### Images actuelles (temporaires - Unsplash)
Ces images seront remplacées par vos vraies photos :

**Image Hero (accueil) :**
- `https://images.unsplash.com/photo-1758612120966-b20c01160c7b` → `hero-main.jpg`

**Portfolio Avant/Après :**
- Avant : `photo-1673370491774-42a963ca1ffd` → `projet-01-avant.jpg`
- Après : `photo-1758812647166-6d4166137f19` → `projet-01-apres.jpg`
- Autres projets : photos similaires

### Organisation recommandée dans `/public/`

```
public/
├── images/
│   ├── hero/
│   │   ├── hero-main.jpg (1920x1080)
│   │   └── hero-mobile.jpg (750x1334)
│   ├── portfolio/
│   │   ├── projet-01-avant.jpg
│   │   ├── projet-01-apres.jpg
│   │   ├── projet-01-thumb.jpg (400x300)
│   │   └── ... (6 projets total)
│   ├── services/
│   │   ├── consultation.jpg
│   │   ├── conception-3d.jpg
│   │   └── realisation.jpg
│   └── processus/
│       ├── analyse-terrain.jpg
│       ├── conception-3d.jpg
│       └── accompagnement.jpg
└── videos/
    ├── papillon-presentation.mp4 (30-60s)
    ├── portfolio/
    │   ├── projet-01-transformation.mp4
    │   └── projet-02-transformation.mp4
    └── processus/
        ├── visite-3d-exemple.mp4
        └── timelapse-realisation.mp4
```

## 🎥 Nouvelles Fonctionnalités Vidéo

### 1. **Composant VideoPlayer**
- Lecture automatique avec son coupé
- Contrôles personnalisés
- Fallback vers image si vidéo indisponible
- Support mobile optimisé

### 2. **Page Galerie** (nouvelle)
- **Photos** : Avant/après organisées
- **Vidéos** : Transformations + processus
- **Conception 3D** : Rendus et visualisations
- Modal de visualisation plein écran

### 3. **Vidéo Hero** (optionnelle)
- Remplace l'image statique par une vidéo en boucle
- Son coupé automatiquement
- Fallback vers image si problème

## 🔧 Comment Utiliser

### Étape 1 : Préparer vos médias
1. **Photos** : Format JPG, max 2MB, dimensions recommandées
2. **Vidéos** : Format MP4, max 50MB, résolution HD minimum
3. **Optimisation** : TinyPNG pour images, HandBrake pour vidéos

### Étape 2 : Organiser les fichiers
1. Créez la structure de dossiers dans `/public/`
2. Nommez vos fichiers selon les conventions
3. Respectez les dimensions recommandées

### Étape 3 : Configuration
Le fichier `/components/ImageConfig.tsx` centralise toutes les URLs :

```typescript
export const MEDIA = {
  images: {
    hero: "/images/hero/hero-main.jpg",
    portfolio: [
      {
        id: 1,
        before: "/images/portfolio/projet-01-avant.jpg",
        after: "/images/portfolio/projet-01-apres.jpg"
      }
    ]
  },
  videos: {
    hero: "/videos/papillon-presentation.mp4"
  }
};
```

## 📋 Checklist de Migration

### Phase 1 : Images Essentielles
- [ ] Image hero principale (accueil)
- [ ] 3 projets avant/après minimum
- [ ] Images des services principaux

### Phase 2 : Portfolio Complet
- [ ] 6 projets avant/après
- [ ] Miniatures optimisées
- [ ] Images du processus

### Phase 3 : Contenu Vidéo
- [ ] Vidéo de présentation (30-60s)
- [ ] 2-3 transformations en timelapse
- [ ] Démonstration processus 3D

### Phase 4 : Optimisation
- [ ] Compression des images
- [ ] Formats vidéo optimisés
- [ ] Tests de performance

## 🎨 Conseils Créatifs

### Pour les Photos
- **Éclairage** : Privilégier la lumière naturelle
- **Angles** : Varier les points de vue
- **Détails** : Montrer la qualité des matériaux
- **Ambiance** : Capturer l'usage des espaces

### Pour les Vidéos
- **Stabilité** : Utiliser un trépied
- **Mouvement** : Plans fluides et lents
- **Durée** : Courts et percutants (10-30s pour portfolio)
- **Storytelling** : Montrer la transformation

## 🔍 Test et Validation

1. **Performance** : Vérifier les temps de chargement
2. **Mobile** : Tester sur différents appareils
3. **Navigateurs** : Safari, Chrome, Firefox
4. **Accessibilité** : Alt texts et descriptions

## 📞 Support

Si vous avez des questions sur l'organisation des médias :
1. Consultez ce guide en premier
2. Vérifiez la structure dans `/public/images/README.md`
3. Testez les composants `VideoPlayer` et `ImageWithFallback`

## 🚀 Fonctionnalités Avancées (futures)

- **Lazy loading** automatique des images
- **Formats WebP** pour une meilleure compression
- **CDN** pour l'hébergement des médias
- **Galerie en plein écran** avec navigation clavier
- **Partage social** des réalisations