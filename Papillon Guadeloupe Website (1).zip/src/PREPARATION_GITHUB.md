# 🎯 PRÉPARATION DOSSIER GITHUB - GUIDE COMPLET

## 🚀 OBJECTIF

Créer un dossier propre et téléchargeable contenant **UNIQUEMENT** les fichiers nécessaires pour déployer le site Papillon Guadeloupe sur GitHub/Vercel.

---

## 📋 MÉTHODE 1 : CRÉATION D'UN NOUVEAU DOSSIER (Recommandé)

### Étape 1 : Créer le Dossier de Base

1. Créez un **nouveau dossier** sur votre ordinateur :
   ```
   Nom : papillon-guadeloupe-deploy
   ```

2. À l'intérieur, créez ces **sous-dossiers** :
   ```
   papillon-guadeloupe-deploy/
   ├── components/
   ├── pages/
   ├── public/
   └── styles/
   ```

---

### Étape 2 : Copier les Fichiers Racine

Depuis votre projet actuel, **copiez** ces fichiers dans `papillon-guadeloupe-deploy/` :

```
✅ .gitignore
✅ App.tsx
✅ index.html
✅ LICENSE
✅ main.tsx
✅ package.json
✅ README.md
✅ tsconfig.json
✅ vercel.json
✅ vite.config.ts
```

**Comment copier** :
- Sélectionnez ces 10 fichiers
- Clic droit → Copier
- Collez dans `papillon-guadeloupe-deploy/`

---

### Étape 3 : Copier le Dossier components/

1. Ouvrez le dossier `components/` de votre projet actuel
2. **Sélectionnez TOUT** le contenu :
   - BackButton.tsx
   - ImageConfig.tsx
   - Layout.tsx
   - ScrollToTop.tsx
   - VideoPlayer.tsx
   - Dossier `figma/` (entier)
   - Dossier `ui/` (entier avec tous ses fichiers)
3. Copiez tout
4. Collez dans `papillon-guadeloupe-deploy/components/`

**Vérification** : Le dossier doit contenir ~61 fichiers

---

### Étape 4 : Copier le Dossier pages/

1. Ouvrez le dossier `pages/` de votre projet actuel
2. **Sélectionnez TOUS** les fichiers :
   ```
   About.tsx
   Contact.tsx
   EntretienPaysager.tsx
   FAQ.tsx
   Galerie.tsx
   Home.tsx
   LocationMotoculteur.tsx
   MentionsLegales.tsx
   NotFound.tsx
   Processus.tsx
   Realisations.tsx
   Services.tsx
   ```
3. Copiez tout
4. Collez dans `papillon-guadeloupe-deploy/pages/`

**Vérification** : Le dossier doit contenir 12 fichiers

---

### Étape 5 : Copier le Dossier public/

1. Ouvrez le dossier `public/` de votre projet actuel
2. **Copiez** :
   ```
   manifest.json
   robots.txt
   sitemap.xml
   Dossier images/ (avec son README.md)
   ```
3. Collez dans `papillon-guadeloupe-deploy/public/`

**Vérification** : Vous devez avoir 3 fichiers + dossier images/

---

### Étape 6 : Copier le Dossier styles/

1. Ouvrez le dossier `styles/` de votre projet actuel
2. Copiez le fichier `globals.css`
3. Collez dans `papillon-guadeloupe-deploy/styles/`

**Vérification** : 1 fichier

---

### Étape 7 : (Optionnel) Copier les Guides

Si vous voulez garder la documentation :

```
✅ DEPLOIEMENT_GITHUB.md
✅ GUIDE_DEPLOIEMENT_NOM_DE_DOMAINE.md
✅ GUIDE_DEMARRAGE_RAPIDE.md
✅ INSTRUCTIONS_UPLOAD_GITHUB.md
```

Copiez-les dans `papillon-guadeloupe-deploy/`

---

### Étape 8 : Vérification Finale

Votre dossier `papillon-guadeloupe-deploy/` doit ressembler à ceci :

```
papillon-guadeloupe-deploy/
│
├── components/
│   ├── BackButton.tsx
│   ├── ImageConfig.tsx
│   ├── Layout.tsx
│   ├── ScrollToTop.tsx
│   ├── VideoPlayer.tsx
│   ├── figma/
│   │   └── ImageWithFallback.tsx
│   └── ui/
│       └── (tous les fichiers Shadcn)
│
├── pages/
│   ├── About.tsx
│   ├── Contact.tsx
│   ├── EntretienPaysager.tsx
│   ├── FAQ.tsx
│   ├── Galerie.tsx
│   ├── Home.tsx
│   ├── LocationMotoculteur.tsx
│   ├── MentionsLegales.tsx
│   ├── NotFound.tsx
│   ├── Processus.tsx
│   ├── Realisations.tsx
│   └── Services.tsx
│
├── public/
│   ├── images/
│   │   └── README.md
│   ├── manifest.json
│   ├── robots.txt
│   └── sitemap.xml
│
├── styles/
│   └── globals.css
│
├── .gitignore
├── App.tsx
├── index.html
├── LICENSE
├── main.tsx
├── package.json
├── README.md
├── tsconfig.json
├── vercel.json
└── vite.config.ts
```

**Checklist de vérification** :
- [ ] ~88 fichiers au total
- [ ] Taille du dossier < 5 MB
- [ ] Tous les dossiers présents
- [ ] package.json présent
- [ ] PAS de node_modules/
- [ ] PAS de dist/

---

## 📋 MÉTHODE 2 : NETTOYAGE DU DOSSIER ACTUEL

Si vous préférez nettoyer le dossier actuel :

### Fichiers à Supprimer

Supprimez tous ces fichiers :

```
❌ AMELIORATIONS.md
❌ App-Complet.tsx
❌ Attributions.md
❌ BOUTON_REALISATIONS_AMELIORE.md
❌ CHECKLIST_DEPLOIEMENT.md
❌ CONFIG_ENTREPRISE.md
❌ CORRECTION_BACKBUTTON.md
❌ CORRECTION_NOTIFICATIONS.md
❌ DEMO_NOTIFICATIONS.md
❌ GUIDE_FINALISATION_5MIN.md
❌ GUIDE_MEDIAS.md
❌ INFORMATIONS_LEGALES_INTEGREES.md
❌ LISTE_FICHIERS_A_VERIFIER.md
❌ MISE_A_JOUR_COMPLETE.md
❌ MODIFICATIONS_FINALES.md
❌ NOTIFICATIONS_FORMULAIRES.md
❌ PRESENTATION_ENTREPRISE.md
❌ RECAP_BOUTON_RETOUR.md
❌ RESOLUTION_FINALE_TOASTER.md
❌ SCRIPT_REMPLACEMENT_RAPIDE.ps1
❌ SCRIPT_REMPLACEMENT_RAPIDE.sh
❌ SITE_FINALISE.md
❌ TEST_NOTIFICATIONS.md
❌ TOUTES_CORRECTIONS_OK.md
❌ TOUT_EST_PRET.md
```

### Dossiers à Supprimer

```
❌ guidelines/
❌ node_modules/ (si présent)
❌ dist/ (si présent)
```

### Fichiers à Garder

**NE SUPPRIMEZ PAS** :
```
✅ README.md
✅ DEPLOIEMENT_GITHUB.md
✅ GUIDE_DEPLOIEMENT_NOM_DE_DOMAINE.md
✅ GUIDE_DEMARRAGE_RAPIDE.md
✅ INSTRUCTIONS_UPLOAD_GITHUB.md
✅ LISTE_FICHIERS_GITHUB.md
✅ FICHIERS_POUR_GITHUB.md
```

---

## 🧪 TESTER LE DOSSIER

Avant d'uploader sur GitHub, testez que tout fonctionne :

### 1. Ouvrir un Terminal

Naviguez vers le dossier :
```bash
cd chemin/vers/papillon-guadeloupe-deploy
```

### 2. Installer les Dépendances

```bash
npm install
```

⏱️ **Attendez 1-2 minutes**. Cela va créer le dossier `node_modules/` (ne pas l'uploader sur GitHub).

### 3. Lancer le Site

```bash
npm run dev
```

Le site devrait s'ouvrir sur **http://localhost:5173**

### 4. Vérifications

- [ ] Page d'accueil s'affiche
- [ ] Navigation fonctionne
- [ ] Toutes les pages accessibles
- [ ] Images se chargent
- [ ] Aucune erreur dans la console

### 5. Arrêter le Serveur

Appuyez sur `Ctrl+C` dans le terminal

---

## 📤 UPLOADER SUR GITHUB

Une fois le dossier prêt et testé :

### 1. Créer le Repository

1. Allez sur **https://github.com**
2. Cliquez sur **"+"** → **"New repository"**
3. **Repository name** : `papillon-guadeloupe`
4. **Description** : `Site officiel de Papillon Guadeloupe SASU - Paysagiste en Guadeloupe`
5. **Public** ✅
6. **Create repository**

### 2. Uploader les Fichiers

**IMPORTANT** : N'uploadez PAS le dossier `node_modules/` qui a été créé !

1. Sur GitHub, cliquez : **"uploading an existing file"**
2. **Sélectionnez TOUS les fichiers** de `papillon-guadeloupe-deploy/` :
   - Maintenez `Ctrl` (Windows) ou `Cmd` (Mac)
   - Sélectionnez TOUS les fichiers et dossiers
   - **SAUF** : `node_modules/`
3. Glissez-déposez sur GitHub
4. Message : `Initial commit - Site Papillon Guadeloupe`
5. **Commit changes**
6. ⏱️ Attendez que tous les fichiers soient uploadés

### 3. Vérifier l'Upload

Sur la page GitHub, vous devez voir :
- ✅ Dossier `components/`
- ✅ Dossier `pages/`
- ✅ Dossier `public/`
- ✅ Dossier `styles/`
- ✅ Fichier `package.json`
- ✅ Fichier `README.md` affiché en bas
- ✅ ~88 fichiers au total

---

## 🚀 DÉPLOYER SUR VERCEL

1. Allez sur **https://vercel.com**
2. **Sign up** → **Continue with GitHub**
3. **Add New...** → **Project**
4. Sélectionnez : **papillon-guadeloupe**
5. **Import**
6. Configuration (auto-détectée) :
   - Framework : Vite ✅
   - Build Command : `npm run build` ✅
   - Output Directory : `dist` ✅
7. **Deploy**
8. ⏱️ Attendez 2-3 minutes
9. **🎉 SITE EN LIGNE !**

URL : `https://papillon-guadeloupe.vercel.app`

---

## 📊 RÉCAPITULATIF

### Ce Que Vous Avez Fait

1. ✅ Créé un dossier propre avec uniquement les fichiers nécessaires
2. ✅ Testé localement que tout fonctionne
3. ✅ Uploadé sur GitHub
4. ✅ Déployé sur Vercel
5. ✅ Site accessible en ligne !

### Fichiers Uploadés

- **Nombre total** : ~88 fichiers
- **Taille** : < 5 MB
- **Contenu** : Code source uniquement (pas de node_modules)

### Résultat

- **URL temporaire** : `https://papillon-guadeloupe.vercel.app`
- **Coût** : 0€ (gratuit)
- **Mise à jour** : Automatique quand vous modifiez GitHub

---

## 🎯 PROCHAINES ÉTAPES

### 1. Ajouter un Nom de Domaine (Optionnel)

Voir le guide : `GUIDE_DEPLOIEMENT_NOM_DE_DOMAINE.md`

**Coût** : 6-8€/an pour un `.fr`

### 2. Configurer le Formulaire de Contact

Options :
- **Formspree** (gratuit) - https://formspree.io
- **EmailJS** (gratuit) - https://emailjs.com

### 3. Ajouter Google Analytics

Pour suivre vos visiteurs (gratuit)

### 4. SEO

- Soumettre à Google Search Console
- Vérifier le sitemap.xml

---

## 🆘 PROBLÈMES COURANTS

### "npm install ne fonctionne pas"

**Solution** :
- Vérifiez que Node.js est installé : `node --version`
- Réinstallez Node.js depuis https://nodejs.org

### "Erreur lors du build sur Vercel"

**Solution** :
- Vérifiez que `package.json` est uploadé
- Regardez les logs d'erreur dans Vercel

### "Les images ne s'affichent pas"

**Solution** :
- Vérifiez que le dossier `public/` est uploadé
- Vérifiez `ImageConfig.tsx`

---

## ✅ CHECKLIST FINALE

- [ ] Dossier `papillon-guadeloupe-deploy` créé
- [ ] ~88 fichiers copiés
- [ ] Testé avec `npm install` et `npm run dev`
- [ ] Repository GitHub créé
- [ ] Fichiers uploadés (sauf node_modules)
- [ ] Projet déployé sur Vercel
- [ ] Site accessible en ligne
- [ ] Toutes les pages fonctionnent

---

**🎉 FÉLICITATIONS !**

Votre site Papillon Guadeloupe est maintenant en ligne et accessible 24/7 partout dans le monde !

---

**PAPILLON GUADELOUPE SASU**  
Architecte paysagiste de jardins d'exception  
SIRET : 830 230 603 00011  
Site : https://papillon-guadeloupe.vercel.app (temporaire)

**Prochaine étape** : Ajoutez votre propre nom de domaine ! 🌐
