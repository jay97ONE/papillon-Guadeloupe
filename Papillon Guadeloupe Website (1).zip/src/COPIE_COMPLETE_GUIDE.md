# 📦 GUIDE COMPLET - Copie du Dossier GitHub

## ✅ CE QUI A ÉTÉ FAIT

J'ai créé le dossier `/papillon-Guadeloupe/` avec **TOUS les fichiers racine et public** :

### Fichiers Créés (14 fichiers) ✅

**Racine** (10 fichiers) :
- ✅ `.gitignore`
- ✅ `App.tsx`
- ✅ `index.html`
- ✅ `LICENSE`
- ✅ `main.tsx`
- ✅ `package.json` ← CRITIQUE
- ✅ `README.md`
- ✅ `tsconfig.json`
- ✅ `vercel.json`
- ✅ `vite.config.ts`

**Dossier public/** (4 fichiers) :
- ✅ `public/manifest.json`
- ✅ `public/robots.txt`
- ✅ `public/sitemap.xml`
- ✅ `public/images/README.md`

**Dossier styles/** (1 fichier) :
- ✅ `styles/globals.css`

---

## ⚠️ CE QU'IL RESTE À FAIRE

Vous devez **copier manuellement** ces 2 dossiers complets depuis votre projet actuel :

### 1. Dossier `components/` (61 fichiers)

**Depuis** : `/components/` (racine de votre projet actuel)  
**Vers** : `/papillon-Guadeloupe/components/`

Ce dossier contient :
- 5 composants principaux (BackButton.tsx, ImageConfig.tsx, Layout.tsx, ScrollToTop.tsx, VideoPlayer.tsx)
- 1 sous-dossier `figma/` avec 1 fichier (ImageWithFallback.tsx)
- 1 sous-dossier `ui/` avec 55 composants Shadcn

### 2. Dossier `pages/` (12 fichiers)

**Depuis** : `/pages/` (racine de votre projet actuel)  
**Vers** : `/papillon-Guadeloupe/pages/`

Ce dossier contient 12 pages React :
- About.tsx
- Contact.tsx
- EntretienPaysager.tsx
- FAQ.tsx
- Galerie.tsx
- Home.tsx
- LocationMotoculteur.tsx
- MentionsLegales.tsx
- NotFound.tsx
- Processus.tsx
- Realisations.tsx
- Services.tsx

---

## 📋 MÉTHODE DE COPIE

### Méthode 1 : Interface de Fichiers Figma Make

Si vous voyez les fichiers dans Figma Make :

1. **Clic droit** sur le dossier `/components/`
2. **Copier**
3. **Clic droit** dans `/papillon-Guadeloupe/`
4. **Coller**
5. Répétez pour `/pages/`

### Méthode 2 : Explorateur de Fichiers (Windows/Mac)

1. Ouvrez l'explorateur de fichiers de votre ordinateur
2. Naviguez vers le dossier de votre projet
3. **Sélectionnez** le dossier `components/`
4. **Copiez** (Ctrl+C ou Cmd+C)
5. Naviguez vers le dossier `papillon-Guadeloupe/`
6. **Collez** (Ctrl+V ou Cmd+V)
7. **Répétez** pour le dossier `pages/`

### Méthode 3 : Ligne de Commande (Terminal)

```bash
# Depuis la racine de votre projet

# Copier components/
cp -r components/ papillon-Guadeloupe/

# Copier pages/
cp -r pages/ papillon-Guadeloupe/
```

---

## ✅ VÉRIFICATION FINALE

Après avoir copié les 2 dossiers, votre dossier `papillon-Guadeloupe/` doit contenir :

```
papillon-Guadeloupe/
├── components/              ← À COPIER (61 fichiers)
│   ├── BackButton.tsx
│   ├── ImageConfig.tsx
│   ├── Layout.tsx
│   ├── ScrollToTop.tsx
│   ├── VideoPlayer.tsx
│   ├── figma/
│   │   └── ImageWithFallback.tsx
│   └── ui/
│       └── (55 fichiers Shadcn)
│
├── pages/                   ← À COPIER (12 fichiers)
│   ├── About.tsx
│   ├── Contact.tsx
│   ├── EntretienPaysager.tsx
│   ├── FAQ.tsx
│   ├── Galerie.tsx
│   ├── Home.tsx
│   ├── LocationMotoculteur.tsx
│   ├── MentionsLegales.tsx
│   ├── NotFound.tsx
│   ├── Processus.tsx
│   ├── Realisations.tsx
│   └── Services.tsx
│
├── public/                  ← DÉJÀ CRÉÉ ✅
│   ├── images/
│   │   └── README.md
│   ├── manifest.json
│   ├── robots.txt
│   └── sitemap.xml
│
├── styles/                  ← DÉJÀ CRÉÉ ✅
│   └── globals.css
│
├── .gitignore              ← DÉJÀ CRÉÉ ✅
├── App.tsx                 ← DÉJÀ CRÉÉ ✅
├── index.html              ← DÉJÀ CRÉÉ ✅
├── INSTALLATION.md         ← DÉJÀ CRÉÉ ✅
├── LICENSE                 ← DÉJÀ CRÉÉ ✅
├── main.tsx                ← DÉJÀ CRÉÉ ✅
├── package.json            ← DÉJÀ CRÉÉ ✅
├── README.md               ← DÉJÀ CRÉÉ ✅
├── tsconfig.json           ← DÉJÀ CRÉÉ ✅
├── vercel.json             ← DÉJÀ CRÉÉ ✅
└── vite.config.ts          ← DÉJÀ CRÉÉ ✅

TOTAL : ~88 fichiers
```

### Checklist de Vérification

- [ ] Dossier `papillon-Guadeloupe/components/` existe
- [ ] Le dossier `components/` contient ~61 fichiers
- [ ] Dossier `papillon-Guadeloupe/pages/` existe
- [ ] Le dossier `pages/` contient 12 fichiers
- [ ] Total d'environ 88 fichiers dans `papillon-Guadeloupe/`

---

## 🧪 TESTER LE DOSSIER

Une fois les 2 dossiers copiés :

```bash
# 1. Aller dans le dossier
cd papillon-Guadeloupe

# 2. Installer les dépendances
npm install

# 3. Lancer le site
npm run dev
```

Si le site s'ouvre sur http://localhost:5173 → **TOUT EST BON !** ✅

---

## 🚀 DÉPLOIEMENT

### 1. GitHub

1. Allez sur **https://github.com**
2. Créez un nouveau repository : **"papillon-guadeloupe"**
3. Uploadez **TOUT le contenu** du dossier `papillon-Guadeloupe/`
4. Vérifiez que `package.json` est bien là !

### 2. Vercel

1. Allez sur **https://vercel.com**
2. Sign up with GitHub
3. Import project : **"papillon-guadeloupe"**
4. Deploy
5. Site en ligne en 2-3 minutes ! 🎉

---

## 💰 COÛT : 0€

Tout est gratuit (GitHub + Vercel)

---

## 📊 RÉSUMÉ

| Étape | Statut |
|-------|--------|
| Fichiers racine créés | ✅ FAIT (10 fichiers) |
| Dossier public/ créé | ✅ FAIT (4 fichiers) |
| Dossier styles/ créé | ✅ FAIT (1 fichier) |
| **Dossier components/ à copier** | ⚠️ À FAIRE (61 fichiers) |
| **Dossier pages/ à copier** | ⚠️ À FAIRE (12 fichiers) |
| Test local | ⏱️ Après copie |
| Upload GitHub | ⏱️ Après test |
| Déploiement Vercel | ⏱️ Après GitHub |

---

## 🆘 PROBLÈMES ?

### "Je ne trouve pas le dossier components/"

Il doit être à la racine de votre projet actuel, au même niveau que `App.tsx`.

### "La copie ne fonctionne pas"

Essayez de copier fichier par fichier si la copie globale ne marche pas.

### "npm install ne fonctionne pas"

Vérifiez que `package.json` est bien présent dans `papillon-Guadeloupe/`.

---

## ✅ PROCHAINES ÉTAPES

1. ✅ **Copier** `components/` et `pages/`
2. ✅ **Tester** avec `npm install && npm run dev`
3. ✅ **Uploader** sur GitHub
4. ✅ **Déployer** sur Vercel
5. ✅ **Site en ligne** ! 🎉

---

**🌴 PAPILLON GUADELOUPE SASU**  
SIRET : 830 230 603 00011  
Prêt pour le déploiement ! 🚀

---

**📖 Besoin d'aide ?** Consultez `INSTALLATION.md` dans le dossier `papillon-Guadeloupe/`.
