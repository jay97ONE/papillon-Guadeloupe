# 🚀 Guide Complet : Mettre en Ligne Papillon Guadeloupe avec un Nom de Domaine

## 📋 Vue d'ensemble

Ce guide vous explique **étape par étape** comment mettre votre site en ligne avec votre propre nom de domaine (ex: `papillon-guadeloupe.fr` ou `papillon-guadeloupe.gp`).

---

## 🎯 ÉTAPE 1 : Déployer le Site Gratuitement

### Option A : Vercel (Recommandé ⭐)

**Pourquoi Vercel ?**
- ✅ Gratuit pour les sites React/Vite
- ✅ Déploiement en 2 minutes
- ✅ HTTPS automatique
- ✅ Configuration domaine très simple
- ✅ Mises à jour automatiques via GitHub

**Instructions :**

1. **Créer un compte GitHub** (si vous n'en avez pas)
   - Allez sur https://github.com
   - Cliquez sur "Sign up" (Inscription)
   - Créez votre compte gratuitement

2. **Mettre votre code sur GitHub**
   - Créez un nouveau repository (dépôt)
   - Uploadez tous vos fichiers du projet
   - ⚠️ **Important** : N'oubliez pas d'inclure `package.json`, `vite.config.ts`, etc.

3. **Déployer sur Vercel**
   - Allez sur https://vercel.com
   - Cliquez sur "Sign up" avec votre compte GitHub
   - Cliquez sur "New Project"
   - Sélectionnez votre repository GitHub
   - Vercel détecte automatiquement que c'est un projet Vite
   - Cliquez sur "Deploy"
   - ⏱️ **Attendez 2-3 minutes** → Votre site est en ligne !

4. **Résultat**
   - Vous obtenez une URL temporaire : `votre-projet.vercel.app`
   - Votre site est déjà accessible partout dans le monde !

---

### Option B : Netlify (Alternative)

**Déploiement via interface drag & drop :**

1. Allez sur https://netlify.com
2. Créez un compte gratuit
3. Cliquez sur "Add new site" → "Deploy manually"
4. **Construisez votre site localement** :
   ```bash
   npm run build
   ```
5. **Glissez-déposez** le dossier `dist` sur Netlify
6. Votre site est en ligne en 1 minute !

**OU via GitHub :**
- Connectez votre repository GitHub
- Netlify construit et déploie automatiquement

---

## 🌐 ÉTAPE 2 : Acheter un Nom de Domaine

### Où acheter ? (Recommandations pour la Guadeloupe)

#### Option 1 : OVH (Recommandé pour .fr et .gp)
- **Site** : 
- **Prix** : 
  - `.fr` : ~6-8€/an
  - `.gp` (Guadeloupe) : ~30-40€/an
  - `.com` : ~8-10€/an
- **Avantages** : Interface en français, support français, parfait pour les Antilles

#### Option 2 : Gandi
- **Site** : https://www.gandi.net
- **Prix similaires**
- **Avantages** : Excellente réputation, interface claire

#### Option 3 : Namecheap (International)
- **Site** : https://www.namecheap.com
- **Prix** : Souvent moins cher pour `.com`
- **Avantages** : Prix compétitifs

### Quels noms de domaine choisir ?

**Suggestions pour Papillon Guadeloupe :**

1. `papillon-guadeloupe.fr` ⭐ (Le meilleur choix)
2. `papillon-guadeloupe.gp` (Extension locale Guadeloupe)
3. `papillon-guadeloupe.com` (International)
4. `papillon-creation.fr`
5. `papillonpaysagiste.fr`

**Vérifiez la disponibilité** sur le site du registrar avant d'acheter.

### Comment acheter (Exemple OVH) :

1. Allez sur https://www.ovh.com/fr/domaines/
2. Tapez le nom souhaité : `papillon-guadeloupe`
3. Choisissez l'extension (`.fr`, `.gp`, `.com`)
4. Ajoutez au panier
5. **Options à cocher** :
   - ✅ Protection des données WHOIS (recommandé)
   - ❌ Hébergement (pas nécessaire si vous utilisez Vercel/Netlify)
   - ❌ Email (vous pouvez ajouter plus tard)
6. Payez (~6-40€/an selon l'extension)
7. **Vous êtes propriétaire du domaine !**

---

## 🔗 ÉTAPE 3 : Connecter le Domaine au Site

### Avec Vercel (Méthode Recommandée)

#### 3.1 Dans Vercel

1. Connectez-vous à https://vercel.com
2. Allez dans votre projet "papillon-guadeloupe"
3. Cliquez sur **"Settings"** (Paramètres)
4. Cliquez sur **"Domains"** dans le menu de gauche
5. Tapez votre nom de domaine : `papillon-guadeloupe.fr`
6. Cliquez sur **"Add"**
7. Vercel vous donne des **instructions de configuration DNS**

**Note importante** : Vercel va vous donner une des deux options :

**Option A : Configuration avec Nameservers (Plus Simple ⭐)**
- Vercel vous donne des nameservers (ex: `ns1.vercel-dns.com`)
- Vous devez les configurer chez OVH (voir ci-dessous)

**Option B : Configuration avec enregistrements A/CNAME**
- Vercel vous donne des adresses IP ou CNAME
- Vous devez créer des enregistrements DNS chez OVH

#### 3.2 Dans OVH (Configuration DNS)

**Méthode A : Nameservers (Recommandé - Plus Simple)**

1. Connectez-vous à https://www.ovh.com/manager/
2. Allez dans **"Noms de domaine"**
3. Cliquez sur votre domaine (`papillon-guadeloupe.fr`)
4. Cliquez sur l'onglet **"Serveurs DNS"**
5. Cliquez sur **"Modifier les serveurs DNS"**
6. Remplacez les serveurs DNS OVH par ceux de Vercel :
   ```
   ns1.vercel-dns.com
   ns2.vercel-dns.com
   ```
7. Validez
8. ⏱️ **Attendez 24-48h** pour la propagation DNS

**Méthode B : Enregistrements A/CNAME**

1. Connectez-vous à https://www.ovh.com/manager/
2. Allez dans **"Noms de domaine"**
3. Cliquez sur votre domaine
4. Allez dans **"Zone DNS"**
5. Cliquez sur **"Ajouter une entrée"**

**Pour le domaine principal** (`papillon-guadeloupe.fr`) :
- Type : `A`
- Sous-domaine : vide ou `@`
- Cible : L'adresse IP donnée par Vercel (ex: `76.76.21.21`)

**Pour www** (`www.papillon-guadeloupe.fr`) :
- Type : `CNAME`
- Sous-domaine : `www`
- Cible : `cname.vercel-dns.com`

6. Validez
7. ⏱️ **Attendez 1-24h** pour la propagation DNS

---

### Avec Netlify (Alternative)

1. Dans Netlify, allez dans **"Domain settings"**
2. Cliquez sur **"Add custom domain"**
3. Tapez votre domaine : `papillon-guadeloupe.fr`
4. Netlify vous donne les enregistrements DNS
5. Configurez-les dans OVH (même méthode qu'avec Vercel)

---

## ✅ ÉTAPE 4 : Vérifications Finales

### 4.1 Attendez la Propagation DNS

⏱️ **Temps d'attente** : 1h à 48h (généralement 2-6h)

**Comment vérifier** :
1. Tapez votre domaine dans le navigateur : `https://papillon-guadeloupe.fr`
2. Si ça ne marche pas tout de suite, **c'est normal** !
3. Testez avec : https://dnschecker.org
   - Entrez votre domaine
   - Vérifiez la propagation mondiale

### 4.2 Vérifiez le HTTPS

- Vercel/Netlify activent **automatiquement HTTPS**
- Votre site sera accessible en `https://` (sécurisé 🔒)
- Aucune configuration nécessaire !

### 4.3 Testez Toutes les Pages

Vérifiez que tout fonctionne :
- ✅ Page d'accueil
- ✅ Services
- ✅ Réalisations
- ✅ Galerie
- ✅ Contact (formulaire)
- ✅ Toutes les images s'affichent
- ✅ Responsive mobile

### 4.4 Configurez les Emails (Optionnel)

**Option 1 : Google Workspace** (Payant ~6€/mois/utilisateur)
- Emails professionnels : `contact@papillon-guadeloupe.fr`
- Interface Gmail
- Très professionnel

**Option 2 : OVH Email** (Gratuit ou ~1€/mois)
- Emails basiques inclus avec le domaine
- Interface webmail OVH

**Option 3 : Redirection Email** (Gratuit)
- Redirigez `contact@papillon-guadeloupe.fr` vers `papillonguadeloupe1@gmail.com`
- Configuration dans OVH : Zone DNS → Redirection email

---

## 📊 Récapitulatif des Coûts

| Service | Coût | Fréquence |
|---------|------|-----------|
| **Hébergement (Vercel/Netlify)** | 0€ | Gratuit à vie |
| **Nom de domaine .fr** | 6-8€ | Par an |
| **Nom de domaine .gp** | 30-40€ | Par an |
| **Nom de domaine .com** | 8-10€ | Par an |
| **Emails (optionnel)** | 0-6€ | Par mois |

**Total minimum** : **6-8€/an** pour un site professionnel complet ! 🎉

---

## 🎯 Checklist de Déploiement

### Avant le déploiement :
- [ ] Vérifier que tous les fichiers sont prêts
- [ ] Tester le site localement (`npm run dev`)
- [ ] Construire le site (`npm run build`)
- [ ] Vérifier que le build fonctionne (`npm run preview`)

### Déploiement :
- [ ] Créer un compte GitHub
- [ ] Uploader le code sur GitHub
- [ ] Créer un compte Vercel
- [ ] Déployer le site
- [ ] Vérifier le site sur l'URL temporaire `.vercel.app`

### Nom de domaine :
- [ ] Acheter le domaine chez OVH/Gandi
- [ ] Ajouter le domaine dans Vercel
- [ ] Configurer les DNS chez le registrar
- [ ] Attendre la propagation DNS
- [ ] Vérifier le site sur le domaine final

### Après déploiement :
- [ ] Tester toutes les pages
- [ ] Tester le formulaire de contact
- [ ] Vérifier le responsive mobile
- [ ] Tester le HTTPS (🔒)
- [ ] Configurer les emails (optionnel)
- [ ] Soumettre le sitemap à Google Search Console

---

## 🆘 Problèmes Courants et Solutions

### "Mon site ne s'affiche pas sur mon domaine"
➡️ **Solution** : Attendez la propagation DNS (jusqu'à 48h). Testez avec https://dnschecker.org

### "J'ai une erreur 404"
➡️ **Solution** : Dans Vercel, vérifiez que le "Build Command" est `npm run build` et "Output Directory" est `dist`

### "Les images ne s'affichent pas"
➡️ **Solution** : Vérifiez que toutes les images sont dans le dossier `public/images` et que les URLs dans `ImageConfig.tsx` sont correctes

### "Le formulaire de contact ne fonctionne pas"
➡️ **Solution** : Pour l'instant, le formulaire utilise `mailto:`. Pour un vrai formulaire, vous devrez configurer un service comme Formspree ou EmailJS (gratuit)

### "Erreur de build sur Vercel"
➡️ **Solution** : 
1. Vérifiez que `package.json` est présent
2. Vérifiez que toutes les dépendances sont installées localement
3. Regardez les logs d'erreur dans Vercel

---

## 📧 Configuration Email Professionnelle (Bonus)

### Option Gratuite : Formspree pour le Formulaire de Contact

1. Allez sur https://formspree.io
2. Créez un compte gratuit
3. Créez un nouveau formulaire
4. Copiez l'URL du formulaire (ex: `https://formspree.io/f/abc123`)
5. Modifiez le fichier `/pages/Contact.tsx` :

```typescript
// Remplacez la fonction handleSubmit par :
const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  
  try {
    const response = await fetch('https://formspree.io/f/VOTRE_ID', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    });
    
    if (response.ok) {
      toast.success("Message envoyé avec succès !");
      setFormData({ name: '', email: '', phone: '', message: '', service: '' });
    }
  } catch (error) {
    toast.error("Erreur lors de l'envoi du message.");
  }
};
```

---

## 🚀 Prochaines Étapes

Une fois le site en ligne :

1. **Référencement (SEO)**
   - Soumettez votre sitemap à Google Search Console
   - Créez un compte Google My Business
   - Ajoutez votre site sur les annuaires locaux Guadeloupe

2. **Analytics**
   - Ajoutez Google Analytics (gratuit)
   - Suivez les visiteurs et les conversions

3. **Performance**
   - Testez avec Google PageSpeed Insights
   - Optimisez les images si nécessaire

4. **Marketing**
   - Partagez votre site sur les réseaux sociaux
   - Ajoutez l'URL sur vos cartes de visite
   - Mettez à jour vos signatures email

---

## 📞 Besoin d'Aide ?

Si vous rencontrez des difficultés :

1. **Documentation Vercel** : https://vercel.com/docs
2. **Support OVH** : https://www.ovh.com/fr/support/
3. **Communauté** : Stack Overflow, Reddit r/webdev

---

## 🎉 Félicitations !

Vous allez bientôt avoir un **site professionnel en ligne** avec votre propre nom de domaine !

**Votre site sera accessible 24/7 partout dans le monde** 🌍

---

**Dernière mise à jour** : Octobre 2025
**Créé pour** : Papillon Guadeloupe Création
